import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { OfficeSetupPage } from "./office-setup.page";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

const routes: Routes = [
    {
        path: "",
        component: OfficeSetupPage,
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes), FormsModule, ReactiveFormsModule],
    exports: [RouterModule],
})
export class OfficeSetupPageRoutingModule {}
