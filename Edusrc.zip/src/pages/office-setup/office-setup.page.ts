import { Component, OnInit } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import {
    AlertController,
    ModalController,
    ToastController,
} from "@ionic/angular";
import { ActivatedRoute, Router } from "@angular/router";
import { NewUserRegistrationPage } from "../new-user-registration/new-user-registration.page";
import { FileUploader } from "ng2-file-upload";
import { AngularFireStorage } from "@angular/fire/storage";
import { FirebaseService } from "src/services/firebase.service";
import { Geolocation } from "@ionic-native/geolocation/ngx";

@Component({
    selector: "app-office-setup",
    templateUrl: "./office-setup.page.html",
    styleUrls: ["./office-setup.page.scss"],
    providers: [Geolocation],
})
export class OfficeSetupPage implements OnInit {
    public uploader: FileUploader = new FileUploader({});
    hOfficeSetupForm;
    hOfficeType;
    hCompanyLogo: string = "../assets/img/LogoPlaceHolder.png";

    hCountry;
    hRegion;
    hDepartments = [];

    hCountries = [
        { id: 1, name: "India" },
        { id: 2, name: "South Africa" },
    ];
    hRegions = [
        { id: 1, name: "Alor Gajah", country_id: 1, country_name: "India" },
        { id: 2, name: "Jasin", country_id: 1, country_name: "India" },
        { id: 3, name: "Muar", country_id: 1, country_name: "India" },
        { id: 4, name: "Segamat", country_id: 1, country_name: "India" },
        { id: 5, name: "Shah Alam", country_id: 1, country_name: "India" },
        { id: 7, name: "Klang", country_id: 1, country_name: "India" },
        {
            id: 8,
            name: "Eastern Cape",
            country_id: 2,
            country_name: "South Africa",
        },
        {
            id: 9,
            name: "Free State",
            country_id: 2,
            country_name: "South Africa",
        },
        {
            id: 10,
            name: "Gauteng",
            country_id: 2,
            country_name: "South Africa",
        },
        {
            id: 11,
            name: "KwaZulu-Natal",
            country_id: 2,
            country_name: "South Africa",
        },
        {
            id: 12,
            name: "Limpopo",
            country_id: 2,
            country_name: "South Africa",
        },
        {
            id: 13,
            name: "Mpumalanga",
            country_id: 2,
            country_name: "South Africa",
        },
        {
            id: 14,
            name: "North West",
            country_id: 2,
            country_name: "South Africa",
        },
        {
            id: 15,
            name: "Northern Cape",
            country_id: 2,
            country_name: "South Africa",
        },
        {
            id: 16,
            name: "Western Cape",
            country_id: 2,
            country_name: "South Africa",
        },
    ];
    hAreas = [
        { id: 1, name: "City of Alor Gajah 1", country_id: 1, region_id: 1 },
        { id: 2, name: "City of Alor Gajah 2", country_id: 1, region_id: 1 },
        { id: 3, name: "City of Jasin 1", country_id: 1, region_id: 2 },
        { id: 4, name: "City of Muar 1", country_id: 1, region_id: 3 },
        { id: 5, name: "City of Muar 2", country_id: 1, region_id: 3 },
        { id: 6, name: "City of Segamat 1", country_id: 1, region_id: 4 },
        { id: 7, name: "City of Shah Alam 1", country_id: 1, region_id: 5 },
        { id: 8, name: "City of Klang 1", country_id: 1, region_id: 6 },
        { id: 9, name: "City of Klang 2", country_id: 1, region_id: 6 },
        { id: 10, name: "Alice", country_id: 2, region_id: 8 },
        { id: 11, name: "Butterworth", country_id: 2, region_id: 8 },
        { id: 12, name: "East London", country_id: 2, region_id: 8 },
        { id: 13, name: "Graaff-Reinet", country_id: 2, region_id: 8 },
        { id: 14, name: "Grahamstown", country_id: 2, region_id: 8 },
        { id: 15, name: "King William’s Town", country_id: 2, region_id: 8 },
        { id: 16, name: "Mthatha", country_id: 2, region_id: 8 },
        { id: 17, name: "Port Elizabeth", country_id: 2, region_id: 8 },
        { id: 18, name: "Queenstown", country_id: 2, region_id: 8 },
        { id: 19, name: "Uitenhage", country_id: 2, region_id: 8 },
        { id: 20, name: "Zwelitsha", country_id: 2, region_id: 8 },
        { id: 21, name: "Bethlehem", country_id: 2, region_id: 9 },
        { id: 22, name: "Bloemfontein", country_id: 2, region_id: 9 },
        { id: 23, name: "Jagersfontein", country_id: 2, region_id: 9 },
        { id: 24, name: "Kroonstad", country_id: 2, region_id: 9 },
        { id: 25, name: "Odendaalsrus", country_id: 2, region_id: 9 },
        { id: 26, name: "Parys", country_id: 2, region_id: 9 },
        { id: 27, name: "Phuthaditjhaba", country_id: 2, region_id: 9 },
        { id: 28, name: "Virginia", country_id: 2, region_id: 9 },
        { id: 29, name: "Welkom", country_id: 2, region_id: 9 },
        { id: 30, name: "Benoni", country_id: 2, region_id: 10 },
        { id: 31, name: "Boksburg", country_id: 2, region_id: 10 },
        { id: 32, name: "Brakpan", country_id: 2, region_id: 10 },
        { id: 33, name: "Carletonville", country_id: 2, region_id: 10 },
        { id: 34, name: "Germiston", country_id: 2, region_id: 10 },
        { id: 35, name: "Johannesburg", country_id: 2, region_id: 10 },
        { id: 36, name: "Krugersdorp", country_id: 2, region_id: 10 },
        { id: 37, name: "Pretoria", country_id: 2, region_id: 10 },
        { id: 38, name: "Randburg", country_id: 2, region_id: 10 },
        { id: 39, name: "Randfontein", country_id: 2, region_id: 10 },
        { id: 40, name: "Roodepoort", country_id: 2, region_id: 10 },
        { id: 41, name: "Soweto", country_id: 2, region_id: 10 },
        { id: 42, name: "Springs", country_id: 2, region_id: 10 },
        { id: 43, name: "Vanderbijlpark", country_id: 2, region_id: 10 },
        { id: 44, name: "Vereeniging", country_id: 2, region_id: 10 },
        { id: 45, name: "Durban", country_id: 2, region_id: 11 },
        { id: 46, name: "Empangeni", country_id: 2, region_id: 11 },
        { id: 47, name: "Ladysmith", country_id: 2, region_id: 11 },
        { id: 48, name: "Newcastle", country_id: 2, region_id: 11 },
        { id: 49, name: "Pietermaritzburg", country_id: 2, region_id: 11 },
        { id: 50, name: "Pinetown", country_id: 2, region_id: 11 },
        { id: 51, name: "Ulundi", country_id: 2, region_id: 11 },
        { id: 52, name: "Umlazi", country_id: 2, region_id: 11 },
        { id: 53, name: "Giyani", country_id: 2, region_id: 12 },
        { id: 54, name: "Lebowakgomo", country_id: 2, region_id: 12 },
        { id: 55, name: "Musina", country_id: 2, region_id: 12 },
        { id: 56, name: "Phalaborwa", country_id: 2, region_id: 12 },
        { id: 57, name: "Polokwane", country_id: 2, region_id: 12 },
        { id: 58, name: "Seshego", country_id: 2, region_id: 12 },
        { id: 59, name: "Sibasa", country_id: 2, region_id: 12 },
        { id: 60, name: "Thabazimbi", country_id: 2, region_id: 12 },
        { id: 61, name: "Emalahleni", country_id: 2, region_id: 13 },
        { id: 62, name: "Nelspruit", country_id: 2, region_id: 13 },
        { id: 63, name: "Secunda", country_id: 2, region_id: 13 },
        { id: 64, name: "Klerksdorp", country_id: 2, region_id: 14 },
        { id: 65, name: "Mahikeng", country_id: 2, region_id: 14 },
        { id: 66, name: "Mmabatho", country_id: 2, region_id: 14 },
        { id: 67, name: "Potchefstroom", country_id: 2, region_id: 14 },
        { id: 68, name: "Rustenburg", country_id: 2, region_id: 14 },
        { id: 69, name: "Kimberley", country_id: 2, region_id: 15 },
        { id: 70, name: "Kuruman", country_id: 2, region_id: 15 },
        { id: 71, name: "Port Nolloth", country_id: 2, region_id: 15 },
        { id: 72, name: "Bellville", country_id: 2, region_id: 16 },
        { id: 73, name: "Cape Town", country_id: 2, region_id: 16 },
        { id: 74, name: "Constantia", country_id: 2, region_id: 16 },
        { id: 75, name: "George", country_id: 2, region_id: 16 },
        { id: 76, name: "Hopefield", country_id: 2, region_id: 16 },
        { id: 77, name: "Oudtshoorn", country_id: 2, region_id: 16 },
        { id: 78, name: "Paarl", country_id: 2, region_id: 16 },
        { id: 79, name: "Simon’s Town", country_id: 2, region_id: 16 },
        { id: 80, name: "Stellenbosch", country_id: 2, region_id: 16 },
        { id: 81, name: "Swellendam", country_id: 2, region_id: 16 },
        { id: 82, name: "Worcester", country_id: 2, region_id: 16 },
    ];

    public hSelectedRegions: any[];
    public hSelectedAreas: any[];

    constructor(
        private aFormBuilder: FormBuilder,
        private aFirebaseService: FirebaseService,
        private aAlertController: AlertController,
        private aParameters: ActivatedRoute,
        private aModalController: ModalController,
        private aAFStorage: AngularFireStorage,
        private aToastCtrl: ToastController,
        private aRouter: Router,
        private aGeolocation: Geolocation
    ) {
        this.hOfficeSetupForm = this.aFormBuilder.group({
            Country: "",
            Address: "",
            CompanyName: "",
            GPSCoor: "",
            Area: "",
            Region: "",
            Email: "",
            PhoneMobile: "",
            PhoneLandline: "",
            Fax: "",
            CompanyRegNo: "",
            WebsiteURL: "",
            ExpireDate: "",
            VATRegNo: "",
            TaxClearanceCertificate: "",
            HeadOfficeDescription: "",
            Departments: "",
            BEECertificate: "",
            CompanyLogo: "",
        });

        this.aParameters.params.subscribe((aParameters) => {
            if (aParameters && aParameters["officeType"]) {
                this.hOfficeType = aParameters["officeType"];
            }
        });
    }

    ngOnInit() {
        this.aFirebaseService.readCollection("Department").subscribe((data) => {
            this.hDepartments = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    Department: aEntryContent.payload.doc.data()["department"],
                };
            });

            console.log(this.hDepartments);
        });
    }

    async hSubmitForm(aOfficeData) {
        let aFile = await this.uploader.queue.map((fileItem) => {
            return fileItem.file;
        });

        if (aFile && aFile.length > 0) {
            // Create the file metadata
            let lMetaData = {
                contentType: aFile[0].type,
                size: aFile[0].size,
                name: aFile[0].name,
            };

            let uniqueID: string = new Date().getTime().toString(36);

            this.hOfficeSetupForm.value["CompanyLogo"] = uniqueID;

            // Upload file and metadata to the object 'images/mountains.jpg'
            let lUploadTask = this.aAFStorage.upload(
                "CompanyLogo/" + uniqueID,
                aFile[0].rawFile,
                lMetaData
            );

            lUploadTask.then(async (res) => {
                const toast = await this.aToastCtrl.create({
                    duration: 3000,
                    message: "File upload finished!",
                });
                toast.present();
            });
        }

        this.aFirebaseService
            .createCollection(this.hOfficeSetupForm.value, "Company")
            .then((resp) => {
                this.hNextCompanyType();
            })
            .catch((error) => {
                console.log(error);
            });
    }

    async hNextCompanyType() {
        switch (this.hOfficeType) {
            case "Head Office": {
                await (
                    await this.aAlertController.create({
                        header: this.hOfficeType,
                        message: "Does the Head Office have Regional Offices?",
                        buttons: [
                            {
                                text: "Yes",
                                handler: () => {
                                    this.hOfficeType = "Regional Office";
                                },
                            },
                            {
                                text: "No",
                                role: "cancel",
                                cssClass: "secondary",
                                handler: () => {
                                    this.aRouter.navigate(["/login"]);
                                },
                            },
                        ],
                    })
                ).present();
                break;
            }

            case "Branch Office": {
                await (
                    await this.aAlertController.create({
                        header: this.hOfficeType,
                        message: "Does the Head Office have Regional Offices?",
                        buttons: [
                            {
                                text: "Yes",
                                handler: () => {
                                    this.hOfficeType = "Regional Office";
                                },
                            },
                            {
                                text: "No",
                                role: "cancel",
                                cssClass: "secondary",
                                handler: () => {
                                    this.aRouter.navigate(["/login"]);
                                },
                            },
                        ],
                    })
                ).present();
                break;
            }

            case "Regional Office": {
                await (
                    await this.aAlertController.create({
                        header: this.hOfficeType,
                        message:
                            "Does the Head Office or Regional Offices have branch offices?",
                        buttons: [
                            {
                                text: "Yes",
                                handler: () => {
                                    this.hOfficeType = "Branch Office";
                                },
                            },
                            {
                                text: "No",
                                role: "cancel",
                                cssClass: "secondary",
                                handler: () => {
                                    this.aRouter.navigate(["/login"]);
                                },
                            },
                        ],
                    })
                ).present();
                break;
            }
        }
    }

    async hOpenModal() {
        let lData = { hOfficeType: this.hOfficeType };
        let lModalPage = await this.aModalController.create({
            component: NewUserRegistrationPage,
            componentProps: lData,
            cssClass: "new-user-registration",
        });

        lModalPage.present();
    }

    hFileChange(event) {
        if (event.target.files && event.target.files[0]) {
            let reader = new FileReader();

            reader.onload = (event: any) => {
                this.hCompanyLogo = event.target.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    }

    hGetPosition() {
        this.aGeolocation
            .getCurrentPosition()
            .then((resp) => {
                this.hOfficeSetupForm.controls["GPSCoor"].setValue(
                    resp.coords.latitude + ";" + resp.coords.longitude
                );
            })
            .catch((error) => {
                console.log("Error getting location", error);
            });
    }

    hSetRegionValues() {
        this.hSelectedRegions = this.hRegions.filter(
            (aRegion) => aRegion.country_id == this.hCountry.id
        );
    }

    hSetAreaValues() {
        this.hSelectedAreas = this.hAreas.filter(
            (city) => city.region_id == this.hRegion.id
        );
    }

    async hAddDepartments() {
        await (
            await this.aAlertController.create({
                header: "New Department?",
                message: "Insert Name for new department",
                inputs: [
                    {
                        name: "department",
                        placeholder: "Department",
                    },
                ],
                buttons: [
                    {
                        text: "Create",
                        handler: (data) => {
                            this.aFirebaseService
                                .createCollection(data, "Department")
                                .then((resp) => {})
                                .catch((error) => {
                                    console.log(error);
                                });
                        },
                    },
                    {
                        text: "No",
                        role: "cancel",
                        cssClass: "secondary",
                        handler: () => {},
                    },
                ],
            })
        ).present();
    }
}
