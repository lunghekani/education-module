import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { OfficeSetupPageRoutingModule } from './office-setup-routing.module';

import { OfficeSetupPage } from './office-setup.page';
import { FileUploadModule } from 'ng2-file-upload';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    OfficeSetupPageRoutingModule,
    ReactiveFormsModule,
    FileUploadModule
  ],
  declarations: [OfficeSetupPage]
})
export class OfficeSetupPageModule {}
