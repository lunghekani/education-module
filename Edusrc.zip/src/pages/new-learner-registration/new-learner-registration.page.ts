import { Component, OnInit } from "@angular/core";
import { ModalController, AlertController } from "@ionic/angular";
import { FormGroup, FormBuilder } from "@angular/forms";
import { IUserProfile } from "src/interfaces/user.interface";
import { AngularFireAuth } from "@angular/fire/auth";
import { AngularFirestore } from "@angular/fire/firestore";
import { Router } from "@angular/router";
import { UserService } from "src/services/user.local.service";

@Component({
    selector: "app-new-learner-registration",
    templateUrl: "./new-learner-registration.page.html",
    styleUrls: ["./new-learner-registration.page.scss"],
})
export class NewLearnerRegistrationPage implements OnInit {
    hNewUserForm: FormGroup;
    hLearnerSegment: string = "Info";
    aNewUser: IUserProfile = { UserID: "" };

    constructor(
        private aFormBuilder: FormBuilder,
        private aAlertController: AlertController,
        private aAfAuth: AngularFireAuth,
        private aModalController: ModalController,
        private aAfStore: AngularFirestore,
        private aRouter: Router,
        private aUserService: UserService
    ) {
        this.hNewUserForm = this.aFormBuilder.group({
            Title: [""],
            Employer: [""],
            UserName: [""],
            LearnerID: [""],
            PassportNumber: [""],
            FirstName: [""],
            Gender: [""],
            LastName: [""],
            MaritalStatus: [""],
            MaidenName: [""],
            Race: [""],
            disability: [""],
            Email: [""],
            PhoneNr: [""],
            Address: [""],
            Communication: [""],
            PostalAddress: [""],
            SecurityUserName: [""],
            Relation: [""],
            WorkAddress: [""],
            PasswordEmail: [""],
            KinAddress: [""],
            WorkPostalAddress: [""],
            KinPostalAddress: [""],
            WorkEmailAddress: [""],
            KinEmailAddress: [""],
            WorkPhone: [""],
            KinPhone: [""],
        });
    }

    ngOnInit() {}

    async hSubmitForm(aUserData) {
        if (this.hLearnerSegment == "Info") {
            this.hLearnerSegment = "Academic";
        } else if (this.hLearnerSegment == "Academic") {
            this.hLearnerSegment = "Declaration";
        } else {
            console.dir(aUserData);
            try {
                /* TODO: insert real email handling into program */
                const res = await this.aAfAuth.createUserWithEmailAndPassword(
                    aUserData.UserName + "@codedamn.com",
                    "hPassword"
                );

                this.aAfStore
                    .collection("Learner")
                    .doc(res.user.uid)
                    .set(aUserData);

                this.aUserService.setUserID(res.user.uid);
                this.aUserService.setUserName(aUserData.UserName);
                this.aUserService.setAccountType("Learner");

                //TODO: Collect form data
                await (
                    await this.aAlertController.create({
                        header: "@sub-section Office",
                        message:
                            "<ion-icon name='square'></ion-icon> Does the @section Office have @sub-section Offices?",
                        buttons: [
                            {
                                text: "Yes",
                                handler: () => {
                                    console.log("Confirm Okay");
                                    this.aRouter.navigate([
                                        "/administrator-dashboard",
                                    ]);
                                },
                            },
                            {
                                text: "No",
                                role: "cancel",
                                cssClass: "secondary",
                                handler: (blah) => {
                                    console.log("Confirm Cancel: blah");
                                },
                            },
                        ],
                    })
                ).present();
            } catch (err) {
                console.dir(err);
                if (err.code === "auth/user-not-found") {
                    console.log("User not found");
                }
            }
        }
    }

    async hCloseModal() {
        await this.aModalController.dismiss("close");
    }
}
