import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { NewLearnerRegistrationPageRoutingModule } from './new-learner-registration-routing.module';

import { NewLearnerRegistrationPage } from './new-learner-registration.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NewLearnerRegistrationPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [NewLearnerRegistrationPage]
})
export class NewLearnerRegistrationPageModule {}
