import { Component, OnInit } from "@angular/core";
import { AngularFireAuth } from "@angular/fire/auth";
import { Router } from "@angular/router";
import { IUserProfile } from "src/interfaces/user.interface";
import { UserService } from "src/services/user.local.service";
import { AlertController } from "@ionic/angular";

@Component({
    selector: "app-login",
    templateUrl: "./login.page.html",
    styleUrls: ["./login.page.scss"],
})
export class LoginPage implements OnInit {
    hUserName: string = "";
    hPassword: string = "";
    hLoginOption: string = "";
    aUser: IUserProfile;
    hCompanyLogo: string = "../assets/img/REDerpLogo.png";

    constructor(
        private aAfAuth: AngularFireAuth,
        private aRouter: Router,
        private aUserService: UserService,
        private aAlertController: AlertController
    ) {}

    ngOnInit() {}

    async hLoginClick() {
        const { hUserName, hPassword } = this;
        try {
            /* TODO: insert real email handling into program */
            const res = await this.aAfAuth.signInWithEmailAndPassword(
                hUserName + "@codedamn.com",
                hPassword
            );

            if (res.user) {
                this.aUserService.setUserName(hUserName);
                this.aUserService.setUserID(res.user.uid);
                this.aUserService.setAccountType(this.hLoginOption);
            }

            switch (this.hLoginOption) {
                case "Administrator":
                    this.aRouter.navigate(["/administrator-dashboard"]);

                    break;

                case "Assessor":
                    this.aRouter.navigate(["/assessor-home"]);

                    break;

                case "Instructor":
                    this.aRouter.navigate(["/instructor-home"]);

                    break;

                case "Moderator":
                    this.aRouter.navigate(["/moderator-home"]);

                    break;

                case "Learner":
                    this.aRouter.navigate(["/learner-home"]);

                    break;

                default:
                    this.aRouter.navigate(["/administrator-dashboard"]);

                    break;
            }
        } catch (err) {
            console.dir(err);
            await (
                await this.aAlertController.create({
                    header: "Could not Login",
                    message: err.message,
                    buttons: [
                        {
                            text: "Ok",
                            role: "cancel",
                            cssClass: "secondary",
                        },
                    ],
                })
            ).present();

            if (err.code === "auth/user-not-found") {
                console.log("User not found");
            }
        }
    }

    hSignUpClick() {
        switch (this.hLoginOption) {
            case "Learner":
                this.aRouter.navigate(["/new-learner-registration"]);

                break;

            default:
                this.aRouter.navigate(["/office-setup", { officeType: "Head Office" }]);

                break;
        }
    }

    async hForgotPassword() {
        await (
            await this.aAlertController.create({
                header: "Reset Password",
                inputs: [
                    {
                        name: "UserName",
                        id: "AlertUserName",
                        type: "text",
                        placeholder: "Enter User Name",
                    },
                    {
                        name: "SentPassword",
                        type: "text",
                        id: "AlertSentPassword",
                        placeholder: "Enter Sent Password",
                    },
                    // multiline input.
                    {
                        name: "NewPassword",
                        id: "AlertNewPassword",
                        type: "password",
                        placeholder: "Enter New Password",
                    },
                    {
                        name: "NewPassword2",
                        id: "AlertNewPassword2",
                        type: "password",
                        placeholder: "Re-Enter New Password",
                    },
                ],
                buttons: [
                    {
                        text: "Cancel",
                        role: "cancel",
                        cssClass: "secondary",
                        handler: () => {
                            console.log("Confirm Cancel");
                        },
                    },
                    {
                        text: "Ok",
                        handler: () => {
                            console.log("Confirm Ok");
                        },
                    },
                ],
            })
        ).present();
    }
}
