import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ModeratorEvidenceRecordPage } from './moderator-evidence-record.page';

describe('ModeratorEvidenceRecordPage', () => {
  let component: ModeratorEvidenceRecordPage;
  let fixture: ComponentFixture<ModeratorEvidenceRecordPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModeratorEvidenceRecordPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ModeratorEvidenceRecordPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
