import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ModalController } from "@ionic/angular";
import { FirebaseService } from "src/services/firebase.service";
import { UserService } from 'src/services/user.local.service';

@Component({
    selector: "app-moderator-evidence-record",
    templateUrl: "./moderator-evidence-record.page.html",
    styleUrls: ["./moderator-evidence-record.page.scss"],
})
export class ModeratorEvidenceRecordPage implements OnInit {
    hEvidenceForm: FormGroup;
    hLoggedInUser;

    hSystemDocuments = [
        { Name: "Assessment Criteria Grid", Id: "AssessmentCriteriaGrid" },
        { Name: "Evidence Review Record", Id: "EvidenceReviewRecord" },
        { Name: "Non-Compliance Record", Id: "NonComplianceRecord" },
        { Name: "Assessment Evidence Record", Id: "AssessmentEvidenceRecord" },
    ];

    hInstrumentDocuments = [
        { Name: "Task Obsevation", Id: "TaskObsevation" },
        { Name: "Questioning", Id: "Questioning" },
        { Name: "Product Evaluation", Id: "ProductEvaluation" },
        { Name: "Portfolios", Id: "Portfolios" },
        { Name: "Team Outputs", Id: "TeamOutputs" },
        { Name: "Completed Work", Id: "CompletedWork" },
        { Name: "Assigments", Id: "Assigments" },
        { Name: "Formative Tests", Id: "FormativeTests" },
        { Name: "Reports : Practical", Id: "ReportsPractical" },
        { Name: "Testimonials", Id: "Testimonials" },
        { Name: "Other", Id: "Other" },
    ];

    constructor(
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder,
        private aModalController: ModalController,
        private aUserService: UserService
    ) {
        this.hLoggedInUser = this.aUserService.getUserName();

        this.hEvidenceForm = this.aFormBuilder.group({
            Venue: [""],
            AccreditationBodyNumber: [""],
            QualificationsTitle: [""],
            Number: [""],
            LearnerName: [""],
            StudentNumber: [""],
            AssessmentCriteriaGridCompliance: [""],
            AssessmentCriteriaGridLetter: [""],
            AssessmentCriteriaGridPlan: [""],
            AssessmentCriteriaGridAssessment: [""],
            AssessmentCriteriaGridEvaluate: [""],
            AssessmentCriteriaGridOutcomes: [""],
            AssessmentCriteriaGridQuality: [""],
            EvidenceReviewRecordCompliance: [""],
            EvidenceReviewRecordLetter: [""],
            EvidenceReviewRecordPlan: [""],
            EvidenceReviewRecordAssessment: [""],
            EvidenceReviewRecordEvaluate: [""],
            EvidenceReviewRecordOutcomes: [""],
            EvidenceReviewRecordQuality: [""],
            NonComplianceRecordCompliance: [""],
            NonComplianceRecordLetter: [""],
            NonComplianceRecordPlan: [""],
            NonComplianceRecordAssessment: [""],
            NonComplianceRecordEvaluate: [""],
            NonComplianceRecordOutcomes: [""],
            NonComplianceRecordQuality: [""],
            AssessmentEvidenceRecordCompliance: [""],
            AssessmentEvidenceRecordLetter: [""],
            AssessmentEvidenceRecordPlan: [""],
            AssessmentEvidenceRecordAssessment: [""],
            AssessmentEvidenceRecordEvaluate: [""],
            AssessmentEvidenceRecordOutcomes: [""],
            AssessmentEvidenceRecordQuality: [""],
            TaskObsevationCompliance: [""],
            TaskObsevationLetter: [""],
            TaskObsevationPlan: [""],
            TaskObsevationAssessment: [""],
            TaskObsevationEvaluate: [""],
            TaskObsevationOutcomes: [""],
            TaskObsevationQuality: [""],
            QuestioningCompliance: [""],
            QuestioningLetter: [""],
            QuestioningPlan: [""],
            QuestioningAssessment: [""],
            QuestioningEvaluate: [""],
            QuestioningOutcomes: [""],
            QuestioningQuality: [""],
            ProductEvaluationCompliance: [""],
            ProductEvaluationLetter: [""],
            ProductEvaluationPlan: [""],
            ProductEvaluationAssessment: [""],
            ProductEvaluationEvaluate: [""],
            ProductEvaluationOutcomes: [""],
            ProductEvaluationQuality: [""],
            PortfoliosCompliance: [""],
            PortfoliosLetter: [""],
            PortfoliosPlan: [""],
            PortfoliosAssessment: [""],
            PortfoliosEvaluate: [""],
            PortfoliosOutcomes: [""],
            PortfoliosQuality: [""],
            TeamOutputsCompliance: [""],
            TeamOutputsLetter: [""],
            TeamOutputsPlan: [""],
            TeamOutputsAssessment: [""],
            TeamOutputsEvaluate: [""],
            TeamOutputsOutcomes: [""],
            TeamOutputsQuality: [""],
            CompletedWorkCompliance: [""],
            CompletedWorkLetter: [""],
            CompletedWorkPlan: [""],
            CompletedWorkAssessment: [""],
            CompletedWorkEvaluate: [""],
            CompletedWorkOutcomes: [""],
            CompletedWorkQuality: [""],
            AssigmentsCompliance: [""],
            AssigmentsLetter: [""],
            AssigmentsPlan: [""],
            AssigmentsAssessment: [""],
            AssigmentsEvaluate: [""],
            AssigmentsOutcomes: [""],
            AssigmentsQuality: [""],
            FormativeTestsCompliance: [""],
            FormativeTestsLetter: [""],
            FormativeTestsPlan: [""],
            FormativeTestsAssessment: [""],
            FormativeTestsEvaluate: [""],
            FormativeTestsOutcomes: [""],
            FormativeTestsQuality: [""],
            ReportsPracticalCompliance: [""],
            ReportsPracticalLetter: [""],
            ReportsPracticalPlan: [""],
            ReportsPracticalAssessment: [""],
            ReportsPracticalEvaluate: [""],
            ReportsPracticalOutcomes: [""],
            ReportsPracticalQuality: [""],
            TestimonialsCompliance: [""],
            TestimonialsLetter: [""],
            TestimonialsPlan: [""],
            TestimonialsAssessment: [""],
            TestimonialsEvaluate: [""],
            TestimonialsOutcomes: [""],
            TestimonialsQuality: [""],
            OtherCompliance: [""],
            OtherLetter: [""],
            OtherPlan: [""],
            OtherAssessment: [""],
            OtherEvaluate: [""],
            OtherOutcomes: [""],
            OtherQuality: [""],
        });
    }

    ngOnInit() {}

    hCreateCollection() {
        this.aFirebaseService
            .createCollection(this.hEvidenceForm.value, "EvidenceRecord")
            .then((resp) => {
                this.hEvidenceForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }

    hDismissModal() {
        this.aModalController.dismiss();
    }
}
