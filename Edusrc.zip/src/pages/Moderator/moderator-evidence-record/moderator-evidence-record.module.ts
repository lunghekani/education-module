import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ModeratorEvidenceRecordPageRoutingModule } from './moderator-evidence-record-routing.module';

import { ModeratorEvidenceRecordPage } from './moderator-evidence-record.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ModeratorEvidenceRecordPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [ModeratorEvidenceRecordPage]
})
export class ModeratorEvidenceRecordPageModule {}
