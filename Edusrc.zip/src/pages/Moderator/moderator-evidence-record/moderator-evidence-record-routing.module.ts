import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ModeratorEvidenceRecordPage } from './moderator-evidence-record.page';

const routes: Routes = [
  {
    path: '',
    component: ModeratorEvidenceRecordPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ModeratorEvidenceRecordPageRoutingModule {}
