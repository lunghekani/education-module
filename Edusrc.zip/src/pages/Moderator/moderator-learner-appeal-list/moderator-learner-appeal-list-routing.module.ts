import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ModeratorLearnerAppealListPage } from './moderator-learner-appeal-list.page';

const routes: Routes = [
  {
    path: '',
    component: ModeratorLearnerAppealListPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ModeratorLearnerAppealListPageRoutingModule {}
