import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ModeratorLearnerAppealListPage } from './moderator-learner-appeal-list.page';

describe('ModeratorLearnerAppealListPage', () => {
  let component: ModeratorLearnerAppealListPage;
  let fixture: ComponentFixture<ModeratorLearnerAppealListPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModeratorLearnerAppealListPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ModeratorLearnerAppealListPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
