import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { FirebaseService } from 'src/services/firebase.service';
import { LearnerAppealPage } from 'src/pages/appeal/learner-appeal.page';

@Component({
  selector: 'app-moderator-learner-appeal-list',
  templateUrl: './moderator-learner-appeal-list.page.html',
  styleUrls: ['./moderator-learner-appeal-list.page.scss'],
})
export class ModeratorLearnerAppealListPage implements OnInit {
  hContents = [];

  constructor(
      private aModalController: ModalController,
      private aFirebaseService: FirebaseService
  ) {}

  ngOnInit() {
      this.aFirebaseService.readCollection("Appeal").subscribe((data) => {
          this.hContents = data.map((aEntryContent) => {
              return {
                  Id: aEntryContent.payload.doc.id,
                  Resolved: aEntryContent.payload.doc.data()["Resolved"],
                  Course: aEntryContent.payload.doc.data()["Course"],
                  Assessor: aEntryContent.payload.doc.data()["Assessor"],
                  Description: aEntryContent.payload.doc.data()[
                      "Description"
                  ],
                  Steps: aEntryContent.payload.doc.data()["Steps"],
                  Status: aEntryContent.payload.doc.data()["Status"],
        ExpiryDate: aEntryContent.payload.doc.data()["ExpiryDate"],
        Escalated: aEntryContent.payload.doc.data()["Escalated"],
              };
          });
          console.log(this.hContents);
      });
  }

  hRemoveCollection(rowID) {
      this.aFirebaseService.deleteCollection(rowID, "Appeal");
  }

  hUpdateCollection(recordRow) {
      let record = {};
      record["Resolved"] = recordRow.Resolved;
      record["Course"] = recordRow.Course;
      record["Assessor"] = recordRow.Assessor;
      record["Description"] = recordRow.Description;
      record["Steps"] = recordRow.Steps;
      record["Status"] = recordRow.Status;
      record["ExpiryDate"] = recordRow.ExpiryDate;
      this.aFirebaseService.updateCollection(recordRow.Id, record, "Appeal");
}

hEscalateAppeal(recordRow) {
      let record = {};
      record["Status"] = recordRow.Status;
      this.aFirebaseService.updateCollection(recordRow.Id, record, "Appeal");
  }

  async hOpenModal(aItem?) {
      if (!aItem) {
          let lData = { message: "hello world" };
          let lModalPage = await this.aModalController.create({
              component: LearnerAppealPage,
              componentProps: lData,
          });

          lModalPage.present();
      }
  }
}
