import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ModeratorLearnerAppealListPageRoutingModule } from './moderator-learner-appeal-list-routing.module';

import { ModeratorLearnerAppealListPage } from './moderator-learner-appeal-list.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ModeratorLearnerAppealListPageRoutingModule
  ],
  declarations: [ModeratorLearnerAppealListPage]
})
export class ModeratorLearnerAppealListPageModule {}
