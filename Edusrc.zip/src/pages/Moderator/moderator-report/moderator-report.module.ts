import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ModeratorReportPageRoutingModule } from './moderator-report-routing.module';

import { ModeratorReportPage } from './moderator-report.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ModeratorReportPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [ModeratorReportPage]
})
export class ModeratorReportPageModule {}
