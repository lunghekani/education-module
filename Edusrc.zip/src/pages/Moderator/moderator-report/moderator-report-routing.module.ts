import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ModeratorReportPage } from './moderator-report.page';

const routes: Routes = [
  {
    path: '',
    component: ModeratorReportPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ModeratorReportPageRoutingModule {}
