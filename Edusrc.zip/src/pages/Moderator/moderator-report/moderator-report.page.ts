import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { UserService } from 'src/services/user.local.service';

@Component({
    selector: "app-moderator-report",
    templateUrl: "./moderator-report.page.html",
    styleUrls: ["./moderator-report.page.scss"],
})
export class ModeratorReportPage implements OnInit {
    hReportForm: FormGroup;
    hLoggedInUser;

    constructor(private aFormBuilder: FormBuilder,
        private aUserService: UserService) {
        this.hReportForm = this.aFormBuilder.group({
            NameofAQP: [""],
            TitleofQualifications: [""],
            AssessorName: [""],
            AssessorMobileNumber: [""],
            AssessorEmailAddress: [""],
            ModeratorName: [""],
            ModeratorMobileNumber: [""],
            ModeratorEmailAddress: [""],
            Durations: [""],
            LearnersEnrolled: [""],
            ModerationRequired: [""],
            LearnersAssessed: [""],
            LearnersModerated: [""],
            ScriptsModerated: [""],
            LearnersPassed: [""],
            LowestMark: [""],
            HighestMark: [""],
            AverageMark: [""],
            PassRate: [""],
            AssessmentModeratedWith: [""],
            Student: [""],
            StudentId: [""],
            StudentExamNumber: [""],
            StudentAssessorFindings: [""],
            StudentModeratedFindings: [""],
            DetailedCommentsQuestion: [""],
            DetailedComments: [""],
            OverallComments: [""],
            MarkingStandardQuestion: [""],
            MarkingStandard: [""],
            AllAnswersMarkedQuestion: [""],
            AllAnswersMarked: [""],
            ModerationCompleteQuestion: [""],
            ModerationComplete: [""],
            AssessmentStandardQuestion: [""],
            AssessmentStandard: [""],
            MarkAllocationFairQuestion: [""],
            MarkAllocationFair: [""],
            MemmoCorrespondsQuestion: [""],
            MemmoCorresponds: [""],
            ResultRangeAcceptableQuestion: [""],
            ResultRangeAcceptable: [""],
            IncosistinciesNotedQuestion: [""],
            IncosistinciesNoted: [""],
            InconsistenciesRecommendations: [""],
            InconsistenciesRecommendationsModerator: [""],
            OverallCommentsImprove: [""],
            AssessorEvaluationUpheldQuestion: [""],
            AssessorEvaluationUpheld: [""],
            AssessorEvaluationUpheldQuestion2: [""],
            AssessorEvaluationUpheld2: [""],
            ModeratorSignature: [""],
            AQPSignature: [""],
            AQPEmail: [""],
        });
    }

    ngOnInit() {}

    ionViewDidEnter() {
        this.hLoggedInUser = this.aUserService.getUserName();
      }
    

    hCreateUser(){}
}
