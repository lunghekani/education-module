import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ModeratorAssessorResultsPageRoutingModule } from './moderator-assessor-results-routing.module';

import { ModeratorAssessorResultsPage } from './moderator-assessor-results.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ModeratorAssessorResultsPageRoutingModule
  ],
  declarations: [ModeratorAssessorResultsPage]
})
export class ModeratorAssessorResultsPageModule {}
