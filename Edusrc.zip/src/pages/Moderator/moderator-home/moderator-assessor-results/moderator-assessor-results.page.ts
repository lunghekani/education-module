import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moderator-assessor-results',
  templateUrl: './moderator-assessor-results.page.html',
  styleUrls: ['./moderator-assessor-results.page.scss'],
})
export class ModeratorAssessorResultsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
