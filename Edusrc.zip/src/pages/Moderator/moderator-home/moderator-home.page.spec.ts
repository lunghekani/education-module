import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ModeratorHomePage } from './moderator-home.page';

describe('ModeratorHomePage', () => {
  let component: ModeratorHomePage;
  let fixture: ComponentFixture<ModeratorHomePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModeratorHomePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ModeratorHomePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
