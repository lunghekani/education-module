import { Component, OnInit } from "@angular/core";
import { FirebaseService } from "src/services/firebase.service";

@Component({
    selector: "app-moderator-home",
    templateUrl: "./moderator-home.page.html",
    styleUrls: ["./moderator-home.page.scss"],
})
export class ModeratorHomePage implements OnInit {
    hContents = [];
    hPageSegment = "list";
    hCourseLogo: string = "../././assets/img/CoursePlaceHolderImage.jpg";
    hCategory = [{Name:"Accounting"},{Name:"Employee Training"}];

    constructor(
        private aFirebaseService: FirebaseService
    ) {}

    ngOnInit() {
        this.aFirebaseService.readCollection("Course").subscribe((data) => {
            this.hContents = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    CourseName: aEntryContent.payload.doc.data()["CourseName"],
                    CourseCode: aEntryContent.payload.doc.data()["CourseCode"],
                };
            });
            console.log(this.hContents);
        });
    }

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Course");
    }

    hUpdateCollection(recordRow) {
        let record = {};
        record["UnitName"] = recordRow.UnitName;
        record["CourseCode"] = recordRow.CourseCode;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Course");
    }
}
