import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ModeratorEnrolledLearnersPage } from './moderator-enrolled-learners.page';

describe('ModeratorEnrolledLearnersPage', () => {
  let component: ModeratorEnrolledLearnersPage;
  let fixture: ComponentFixture<ModeratorEnrolledLearnersPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModeratorEnrolledLearnersPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ModeratorEnrolledLearnersPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
