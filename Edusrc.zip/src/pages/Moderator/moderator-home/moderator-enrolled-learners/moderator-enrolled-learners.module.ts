import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ModeratorEnrolledLearnersPageRoutingModule } from './moderator-enrolled-learners-routing.module';

import { ModeratorEnrolledLearnersPage } from './moderator-enrolled-learners.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ModeratorEnrolledLearnersPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [ModeratorEnrolledLearnersPage]
})
export class ModeratorEnrolledLearnersPageModule {}
