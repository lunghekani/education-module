import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moderator-enrolled-learners',
  templateUrl: './moderator-enrolled-learners.page.html',
  styleUrls: ['./moderator-enrolled-learners.page.scss'],
})
export class ModeratorEnrolledLearnersPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
