import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ModeratorEnrolledLearnersPage } from './moderator-enrolled-learners.page';

const routes: Routes = [
  {
    path: '',
    component: ModeratorEnrolledLearnersPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ModeratorEnrolledLearnersPageRoutingModule {}
