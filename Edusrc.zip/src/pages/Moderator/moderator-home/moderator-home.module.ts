import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ModeratorHomePageRoutingModule } from './moderator-home-routing.module';

import { ModeratorHomePage } from './moderator-home.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ModeratorHomePageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [ModeratorHomePage]
})
export class ModeratorHomePageModule {}
