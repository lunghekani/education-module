import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AssessorLearnerAppealListPageRoutingModule } from './assessor-learner-appeal-list-routing.module';

import { AssessorLearnerAppealListPage } from './assessor-learner-appeal-list.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AssessorLearnerAppealListPageRoutingModule
  ],
  declarations: [AssessorLearnerAppealListPage]
})
export class AssessorLearnerAppealListPageModule {}
