import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AssessorLearnerAppealListPage } from './assessor-learner-appeal-list.page';

const routes: Routes = [
  {
    path: '',
    component: AssessorLearnerAppealListPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AssessorLearnerAppealListPageRoutingModule {}
