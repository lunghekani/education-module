import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AssessorLearnerAppealListPage } from './assessor-learner-appeal-list.page';

describe('AssessorLearnerAppealListPage', () => {
  let component: AssessorLearnerAppealListPage;
  let fixture: ComponentFixture<AssessorLearnerAppealListPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssessorLearnerAppealListPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AssessorLearnerAppealListPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
