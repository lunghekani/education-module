import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AssessorHomePage } from './assessor-home.page';

describe('AssessorHomePage', () => {
  let component: AssessorHomePage;
  let fixture: ComponentFixture<AssessorHomePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssessorHomePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AssessorHomePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
