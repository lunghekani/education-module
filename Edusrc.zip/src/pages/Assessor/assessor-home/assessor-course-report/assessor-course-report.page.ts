import { Component, OnInit, ElementRef, ViewChild } from "@angular/core";
import { FirebaseService } from "src/services/firebase.service";
import { Chart } from "chart.js";
import { UserService } from 'src/services/user.local.service';

@Component({
    selector: "app-assessor-course-report",
    templateUrl: "./assessor-course-report.page.html",
    styleUrls: ["./assessor-course-report.page.scss"],
})
export class AssessorCourseReportPage implements OnInit {
    @ViewChild("hTrainingBarChart") hTrainingBarChart: ElementRef;
    @ViewChild("hCompletionPieChart") hCompletionPieChart: ElementRef;
    @ViewChild("hPassPieChart") hPassPieChart: ElementRef;

    private barChart: Chart;
    private pieCompleteChart: Chart;
    private piePassChart: Chart;

    hUserCourses = [];
    hPageSegment = "EnrollUsers";
    hLoggedInUser;

    constructor(private aFirebaseService: FirebaseService,
      private aUserService: UserService) {}

    ngOnInit() {
        this.aFirebaseService.readCollection("Course").subscribe((data) => {
            this.hUserCourses = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    CourseName: aEntryContent.payload.doc.data()["CourseName"],
                    Category: aEntryContent.payload.doc.data()["Category"],
                    CourseType: aEntryContent.payload.doc.data()["CourseType"],
                    LastUpdatedOn: aEntryContent.payload.doc.data()[
                        "LastUpdatedOn"
                    ],
                    CourseOwner: aEntryContent.payload.doc.data()[
                        "CourseOwner"
                    ],
                };
            });
            console.log(this.hUserCourses);
        });
    }

    ionViewDidEnter() {
        this.hLoggedInUser = this.aUserService.getUserName();
        this.createBarChart();
        this.createPieChart();
        this.createPiePassChart();
    }

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Course");
    }

    hUpdateCollection(recordRow) {
        let record = {};
        record["CourseName"] = recordRow.CourseName;
        record["Category"] = recordRow.Category;
        record["CourseType"] = recordRow.CourseType;
        record["LastUpdatedOn"] = recordRow.LastUpdatedOn;
        record["Instructor"] = recordRow.Instructor;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Course");
    }

    createBarChart() {
        this.barChart = new Chart(this.hTrainingBarChart.nativeElement, {
            type: "bar",
            data: {
                labels: ["", "", "", "", "", "", "", ""],
                datasets: [
                    {
                        label: "",
                        data: [5, 8, 7, 4, 9, 8, 5, 7],
                        backgroundColor: "rgb(65, 105, 225)", // array should have same number of elements as number of dataset
                        borderColor: "rgb(65, 105, 225)", // array should have same number of elements as number of dataset
                        borderWidth: 1,
                    },
                    {
                        label: "",
                        data: [5, 8, 7, 4, 9, 8, 5, 7],
                        backgroundColor: "rgb(65, 105, 185)", // array should have same number of elements as number of dataset
                        borderColor: "rgb(65, 105, 185)", // array should have same number of elements as number of dataset
                        borderWidth: 1,
                    },
                ],
            },
            options: {
                scales: {
                    yAxes: [
                        {
                            ticks: {
                                beginAtZero: true,
                            },
                        },
                    ],
                },
                height: 300,
            },
        });
    }

    createPieChart() {
        this.pieCompleteChart = new Chart(
            this.hCompletionPieChart.nativeElement,
            {
                type: "pie",
                data: {
                    datasets: [
                        {
                            data: [78, 22],
                            backgroundColor: [
                                "rgb(65, 105, 225)",
                                "rgb(65, 105, 185)",
                            ],
                            hoverBackgroundColor: ["#FFCE56", "#FF6384"],
                        },
                    ],
                },
            }
        );
    }

    createPiePassChart() {
        this.pieCompleteChart = new Chart(this.hPassPieChart.nativeElement, {
            type: "pie",
            data: {
                datasets: [
                    {
                        data: [78, 22],
                        backgroundColor: [
                            "rgb(65, 105, 225)",
                            "rgb(255, 99, 132)",
                        ],
                        hoverBackgroundColor: ["#FFCE56", "#FFF"],
                    },
                ],
            },
        });
    }
}
