import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AssessorCourseReportPage } from './assessor-course-report.page';

const routes: Routes = [
  {
    path: '',
    component: AssessorCourseReportPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AssessorCourseReportPageRoutingModule {}
