import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AssessorCourseReportPageRoutingModule } from './assessor-course-report-routing.module';

import { AssessorCourseReportPage } from './assessor-course-report.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AssessorCourseReportPageRoutingModule
  ],
  declarations: [AssessorCourseReportPage]
})
export class AssessorCourseReportPageModule {}
