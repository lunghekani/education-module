import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AssessorCourseReportPage } from './assessor-course-report.page';

describe('AssessorCourseReportPage', () => {
  let component: AssessorCourseReportPage;
  let fixture: ComponentFixture<AssessorCourseReportPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssessorCourseReportPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AssessorCourseReportPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
