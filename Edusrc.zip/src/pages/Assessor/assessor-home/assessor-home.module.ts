import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AssessorHomePageRoutingModule } from './assessor-home-routing.module';

import { AssessorHomePage } from './assessor-home.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AssessorHomePageRoutingModule
  ],
  declarations: [AssessorHomePage]
})
export class AssessorHomePageModule {}
