import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AssessorEnrollUsersPage } from './assessor-enroll-users.page';

describe('AssessorEnrollUsersPage', () => {
  let component: AssessorEnrollUsersPage;
  let fixture: ComponentFixture<AssessorEnrollUsersPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssessorEnrollUsersPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AssessorEnrollUsersPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
