import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/services/user.local.service';

@Component({
  selector: 'app-assessor-enroll-users',
  templateUrl: './assessor-enroll-users.page.html',
  styleUrls: ['./assessor-enroll-users.page.scss'],
})
export class AssessorEnrollUsersPage implements OnInit {
  hLoggedInUser;
  hUserCourses;

  constructor(private aUserService:UserService) { }

  ngOnInit() {
  }
  
  ionViewDidEnter() {
    this.hLoggedInUser = this.aUserService.getUserName();
  }

}
