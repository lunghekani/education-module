import { Component, OnInit } from "@angular/core";
import { FirebaseService } from "src/services/firebase.service";

@Component({
    selector: "app-assessor-learner-courses-result",
    templateUrl: "./assessor-learner-courses-result.page.html",
    styleUrls: ["./assessor-learner-courses-result.page.scss"],
})
export class AssessorLearnerCoursesResultPage implements OnInit {
    hContents = [];
    hCourse = {
        Category: "Employee Training",
        CourseName: "ET101",
        CourseCode: "{code}",
        Description: "Train Employees in the first employee training session",
    };
    hCourseLogo: string = "../././assets/img/CoursePlaceHolderImage.jpg";

    constructor(private aFirebaseService: FirebaseService) {}

    ngOnInit() {
        this.aFirebaseService.readCollection("Test").subscribe((data) => {
            this.hContents = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    Question: aEntryContent.payload.doc.data()["Question"],
                    Type: aEntryContent.payload.doc.data()["Type"],
                    Answers: aEntryContent.payload.doc.data()["Answers"],
                };
            });
            console.log(this.hContents);
        });
    }

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Test");
    }

    hUpdateCollection(recordRow) {
        let record = {};
        record["Status"] = recordRow.Status;
        record["Type"] = recordRow.Type;
        record["Question"] = recordRow.Question;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Test");
    }
}
