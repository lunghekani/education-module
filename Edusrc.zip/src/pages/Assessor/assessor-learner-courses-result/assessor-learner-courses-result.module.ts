import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AssessorLearnerCoursesResultPageRoutingModule } from './assessor-learner-courses-result-routing.module';

import { AssessorLearnerCoursesResultPage } from './assessor-learner-courses-result.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AssessorLearnerCoursesResultPageRoutingModule
  ],
  declarations: [AssessorLearnerCoursesResultPage]
})
export class AssessorLearnerCoursesResultPageModule {}
