import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AssessorLearnerCoursesResultPage } from './assessor-learner-courses-result.page';

describe('AssessorLearnerCoursesResultPage', () => {
  let component: AssessorLearnerCoursesResultPage;
  let fixture: ComponentFixture<AssessorLearnerCoursesResultPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssessorLearnerCoursesResultPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AssessorLearnerCoursesResultPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
