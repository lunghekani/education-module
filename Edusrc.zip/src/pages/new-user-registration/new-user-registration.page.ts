import { Component, OnInit, Input } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";
import {
    AlertController,
    ToastController,
    ModalController,
} from "@ionic/angular";
import { AngularFireAuth } from "@angular/fire/auth";
import { AngularFirestore } from "@angular/fire/firestore";
import { IUserProfile } from "src/interfaces/user.interface";
import { Router } from "@angular/router";
import { UserService } from "src/services/user.local.service";
import { FirebaseService } from "src/services/firebase.service";
import { AngularFireStorage } from "@angular/fire/storage";
import { FileUploader } from "ng2-file-upload";

@Component({
    selector: "app-new-user-registration",
    templateUrl: "./new-user-registration.page.html",
    styleUrls: ["./new-user-registration.page.scss"],
})
export class NewUserRegistrationPage implements OnInit {
    public uploader: FileUploader = new FileUploader({});
    hNewUserForm: FormGroup;
    aNewUser: IUserProfile = { UserID: "" };
    hPersonLogo: string = "../assets/img/UserPlaceHolderLogo.png";
    hAssessorAssCertificate;
    hAssessorIOCertificate;
    hModeratorAssCertificate;
    hModeratorIOCertificate;
    hFacilitatorAssCertificate;
    hFacilitatorIOCertificate;
    hMentorAssCertificate;
    hMentorIOCertificate;
    hDepartments = [];
    hPositions = [];
    @Input() hOfficeType;

    constructor(
        private aFormBuilder: FormBuilder,
        private aFirebaseService: FirebaseService,
        private aAlertController: AlertController,
        private aAfAuth: AngularFireAuth,
        private aAfStore: AngularFirestore,
        private aUserService: UserService,
        private aModalController: ModalController,
        private aAFStorage: AngularFireStorage,
        private aToastCtrl: ToastController
    ) {
        this.hNewUserForm = this.aFormBuilder.group({
            UserName: [""],
            FirstName: [""],
            LastName: [""],
            Email: [""],
            PhoneNr: [""],
            CV: [""],
            Position: [""],
            Department: [""],
            Location: [""],
            StartDate: [""],
            JobProfile: [""],
            PerformanceAppraisel: [""],
            PDP: [""],
            DirectReportTo: [""],
            IndirectReportTo: [""],
            SecurityUserName: [""],
            PasswordEmail: [""],
            ActiveEmailCheck: [""],
            ActivateAtEmailCheck: [""],
            ActivateAtEmail: [""],
            ExcludeEmailCheck: [""],
            AssessorActiveCheck: [""],
            AssessorIssuedDate: [""],
            AssessorExpireDate: [""],
            ModeratorActiveCheck: [""],
            ModeratorIssuedDate: [""],
            ModeratorExpireDate: [""],
            FacilitatorActiveCheck: [""],
            FacilitatorIssuedDate: [""],
            FacilitatorExpireDate: [""],
            MentorActiveCheck: [""],
            MentorIssuedDate: [""],
            MentorExpireDate: [""],
            AdministratorProfileCheck: [""],
            UserProfileCheck: [""],
        });
    }

    ngOnInit() {
        this.aFirebaseService.readCollection("Department").subscribe((data) => {
            this.hDepartments = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    Department: aEntryContent.payload.doc.data()["department"],
                };
            });

            console.log(this.hDepartments);
        });

        this.aFirebaseService.readCollection("Position").subscribe((data) => {
            this.hPositions = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    Position: aEntryContent.payload.doc.data()["position"],
                };
            });

            console.log(this.hPositions);
        });
    }

    async hCreateUser(aUserData) {
        try {
            /* TODO: insert real email handling into program */
            const res = await this.aAfAuth.createUserWithEmailAndPassword(
                aUserData.UserName + "@codedamn.com",
                "hPassword"
            );

            this.aAfStore.collection("User").doc(res.user.uid).set(aUserData);

            let aFile = await this.uploader.queue.map((fileItem) => {
                return fileItem.file;
            });

            if (aFile && aFile.length > 0) {
                // Create the file metadata
                let lMetaData = {
                    contentType: aFile[0].type,
                    size: aFile[0].size,
                    name: aFile[0].name,
                };

                let uniqueID: string = new Date().getTime().toString(36);

                this.hNewUserForm.value["UserLogo"] = uniqueID;

                // Upload file and metadata to the object 'images/mountains.jpg'
                let lUploadTask = this.aAFStorage.upload(
                    "UserLogo/" + uniqueID,
                    aFile[0].rawFile,
                    lMetaData
                );

                this.aUserService.setUserLogoID(uniqueID);

                lUploadTask.then(async () => {
                    const toast = await this.aToastCtrl.create({
                        duration: 3000,
                        message: "File upload finished!",
                    });
                    toast.present();
                });
            }

            this.aUserService.setUserID(res.user.uid);
            this.aUserService.setUserName(aUserData.UserName);
            this.aUserService.setAccountType("Administrator");

            this.aModalController.dismiss();
        } catch (err) {
            const toast = await this.aToastCtrl.create({
                duration: 3000,
                message: err.code,
            });
            toast.present();
        }
    }

    hDismissModal() {
        this.aModalController.dismiss();
    }

    hChangePersonLogo(event) {
        if (event.target.files && event.target.files[0]) {
            let reader = new FileReader();

            reader.onload = (event: any) => {
                this.hPersonLogo = event.target.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    }

    hClickPersonLogo() {
        document.getElementById("UserLogoUploadFile").click();
    }

    hChangeLinkedItem(event, aLevel: string, aIO: boolean) {
        if (event.target.files && event.target.files[0]) {
            let reader = new FileReader();

            reader.onload = (event: any) => {
                switch (aLevel) {
                    case "assessor":
                        if (aIO) {
                            this.hAssessorAssCertificate = event.target.result;
                        } else {
                            this.hAssessorIOCertificate = event.target.result;
                        }

                        break;
                    case "moderator":
                        if (aIO) {
                            this.hModeratorAssCertificate = event.target.result;
                        } else {
                            this.hModeratorIOCertificate = event.target.result;
                        }

                        break;
                    case "facilitator":
                        if (aIO) {
                            this.hFacilitatorAssCertificate =
                                event.target.result;
                        } else {
                            this.hFacilitatorIOCertificate =
                                event.target.result;
                        }

                        break;
                    case "mentor":
                        if (aIO) {
                            this.hMentorAssCertificate = event.target.result;
                        } else {
                            this.hMentorIOCertificate = event.target.result;
                        }

                        break;

                    default:
                        break;
                }
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    }

    hClickLinkedItem(aLevel: string, aIO: boolean) {
        switch (aLevel) {
            case "assessor":
                if (aIO) {
                    document.getElementById("AssessorAssCertificate").click();
                } else {
                    document.getElementById("AssessorIOCertificate").click();
                }

                break;
            case "moderator":
                if (aIO) {
                    document.getElementById("ModeratorAssCertificate").click();
                } else {
                    document.getElementById("ModeratorIOCertificate").click();
                }

                break;
            case "facilitator":
                if (aIO) {
                    document
                        .getElementById("FacilitatorAssCertificate")
                        .click();
                } else {
                    document.getElementById("FacilitatorIOCertificate").click();
                }

                break;
            case "mentor":
                if (aIO) {
                    document.getElementById("MentorAssCertificate").click();
                } else {
                    document.getElementById("MentorIOCertificate").click();
                }

                break;

            default:
                break;
        }
    }

    async hAddPosition() {
        await (
            await this.aAlertController.create({
                header: "New Position?",
                message: "Insert Name for new Position",
                inputs: [
                    {
                        name: "position",
                        placeholder: "Position",
                    },
                ],
                buttons: [
                    {
                        text: "Create",
                        handler: (data) => {
                            this.aFirebaseService
                                .createCollection(data, "Position")
                                .then((resp) => {})
                                .catch((error) => {
                                    console.log(error);
                                });
                        },
                    },
                    {
                        text: "No",
                        role: "cancel",
                        cssClass: "secondary",
                        handler: () => {},
                    },
                ],
            })
        ).present();
    }
}
