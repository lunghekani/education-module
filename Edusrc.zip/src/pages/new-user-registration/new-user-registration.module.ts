import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { IonicModule } from "@ionic/angular";

import { NewUserRegistrationPageRoutingModule } from "./new-user-registration-routing.module";

import { NewUserRegistrationPage } from "./new-user-registration.page";
import { FileUploadModule } from 'ng2-file-upload';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        IonicModule,
        NewUserRegistrationPageRoutingModule,
        FileUploadModule
    ],
    declarations: [NewUserRegistrationPage],
})
export class NewUserRegistrationPageModule {}
