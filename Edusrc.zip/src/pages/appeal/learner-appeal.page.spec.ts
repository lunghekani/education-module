import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { LearnerAppealPage } from './learner-appeal.page';

describe('LearnerAppealPage', () => {
  let component: LearnerAppealPage;
  let fixture: ComponentFixture<LearnerAppealPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LearnerAppealPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(LearnerAppealPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
