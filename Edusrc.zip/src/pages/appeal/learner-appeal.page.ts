import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learner-appeal',
  templateUrl: './learner-appeal.page.html',
  styleUrls: ['./learner-appeal.page.scss'],
})
export class LearnerAppealPage implements OnInit {
  hStatus;
  hStageCount = 0;
  hAssessor;
  hCourse;
  hNewAppealForm;
  constructor() { }

  ngOnInit() {
  }

  hSubmitLearnerAppeal(){}

  hCreateAppeal(){}

  hExport(){}

}
