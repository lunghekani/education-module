import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InstructorDiscussionPage } from './instructor-discussion.page';

const routes: Routes = [
  {
    path: '',
    component: InstructorDiscussionPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InstructorDiscussionPageRoutingModule {}
