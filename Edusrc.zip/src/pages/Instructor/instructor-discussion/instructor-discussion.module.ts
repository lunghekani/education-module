import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { InstructorDiscussionPageRoutingModule } from './instructor-discussion-routing.module';

import { InstructorDiscussionPage } from './instructor-discussion.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    InstructorDiscussionPageRoutingModule
  ],
  declarations: [InstructorDiscussionPage]
})
export class InstructorDiscussionPageModule {}
