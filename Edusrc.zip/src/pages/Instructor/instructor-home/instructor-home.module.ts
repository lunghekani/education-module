import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { InstructorHomePageRoutingModule } from './instructor-home-routing.module';

import { InstructorHomePage } from './instructor-home.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    InstructorHomePageRoutingModule
  ],
  declarations: [InstructorHomePage]
})
export class InstructorHomePageModule {}
