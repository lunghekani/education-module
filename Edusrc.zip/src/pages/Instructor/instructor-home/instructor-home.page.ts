import { Component, OnInit } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { FirebaseService } from "src/services/firebase.service";
import { InstructorAddConferencePage } from "../instructor-add-conference/instructor-add-conference.page";
import { InstructorAddDiscussionPage } from "../instructor-add-discussion/instructor-add-discussion.page";
import { AdministratorAddCoursePage } from 'src/pages/Administrator/administrator-add-course/administrator-add-course.page';
import { AdministratorAddGroupPage } from 'src/pages/Administrator/administrator-add-group/administrator-add-group.page';
import { UserService } from 'src/services/user.local.service';

@Component({
    selector: "app-instructor-home",
    templateUrl: "./instructor-home.page.html",
    styleUrls: ["./instructor-home.page.scss"],
})
export class InstructorHomePage implements OnInit {
    hContents = [];
    hPageSegment = "list";
    hCourseLogo: string = "../././assets/img/CoursePlaceHolderImage.jpg";
    hCategory = [{Name:"Accounting"},{Name:"Employee Training"}];
    hLoggedInUser;
    // ContentData: ContentData;

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aUserService: UserService
    ) {
        // this.ContentData = {} as ContentData;
    }

    ngOnInit() {
        this.aFirebaseService.readCollection("Course").subscribe((data) => {
            this.hContents = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    CourseName: aEntryContent.payload.doc.data()["CourseName"],
                    CourseCode: aEntryContent.payload.doc.data()["CourseCode"],
                };
            });
            console.log(this.hContents);
        });
    }

    ionViewDidEnter() {
        this.hLoggedInUser = this.aUserService.getUserName();
      }
    

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Course");
    }

    hUpdateCollection(recordRow) {
        let record = {};
        record["UnitName"] = recordRow.UnitName;
        record["CourseCode"] = recordRow.CourseCode;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Course");
    }

    async hOpenModal(aEvent, aPageName) {
        aEvent.stopPropagation();
        let lData = { message: "hello world" };
        let lModalPage;

        switch (aPageName) {
            case "Course": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddCoursePage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }

            case "Group": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddGroupPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }

            case "Conference": {
                lModalPage = await this.aModalController.create({
                    component: InstructorAddConferencePage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }

            case "Discussion": {
                lModalPage = await this.aModalController.create({
                    component: InstructorAddDiscussionPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }

            // case "Calendar": {
            //     lModalPage = await this.aModalController.create({
            //         component: AdministratorAddContentPresentationPage,
            //         componentProps: lData,
            //     });
            //     lModalPage.present();

            //     break;
            // }
        }
    }
}
