import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { InstructorHomePage } from './instructor-home.page';

describe('InstructorHomePage', () => {
  let component: InstructorHomePage;
  let fixture: ComponentFixture<InstructorHomePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstructorHomePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(InstructorHomePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
