import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InstructorHomePage } from './instructor-home.page';

const routes: Routes = [
  {
    path: '',
    component: InstructorHomePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InstructorHomePageRoutingModule {}
