import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { InstructorAddDiscussionPageRoutingModule } from './instructor-add-discussion-routing.module';

import { InstructorAddDiscussionPage } from './instructor-add-discussion.page';
import { FileUploadModule } from 'ng2-file-upload';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    InstructorAddDiscussionPageRoutingModule,
    ReactiveFormsModule,
    FileUploadModule
  ],
  declarations: [InstructorAddDiscussionPage]
})
export class InstructorAddDiscussionPageModule {}
