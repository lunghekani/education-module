import { Component, OnInit } from "@angular/core";
import { FileUploader } from "ng2-file-upload";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ModalController, ToastController } from "@ionic/angular";
import { FirebaseService } from "src/services/firebase.service";
import { AngularFireStorage } from "@angular/fire/storage";

@Component({
    selector: "app-instructor-add-discussion",
    templateUrl: "./instructor-add-discussion.page.html",
    styleUrls: ["./instructor-add-discussion.page.scss"],
})
export class InstructorAddDiscussionPage implements OnInit {
    public uploader: FileUploader = new FileUploader({});
    hNewTopicForm: FormGroup;
    hSelectionValue;

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder,
        private aAFStorage: AngularFireStorage,
        private aToastCtrl: ToastController
    ) {}

    ngOnInit() {
        this.hNewTopicForm = this.aFormBuilder.group({
            TopicName: [""],
			Message: [""],
			ViewableSelection: ["Everybody"]
        });
    }

    async hCloseModal() {
        await this.aModalController.dismiss("close");
    }

    async hCreateCollection() {
        let aFile = await this.uploader.queue.map((fileItem) => {
            return fileItem.file;
        });

        // Create the file metadata
        let lMetaData = {
            contentType: aFile[0].type,
            size: aFile[0].size,
            name: aFile[0].name,
        };

        let uniqueID: string = new Date().getTime().toString(36);

        this.hNewTopicForm.value["FileID"] = uniqueID;

        // Upload file and metadata to the object 'images/mountains.jpg'
        let lUploadTask = this.aAFStorage.upload(
            "TopicFiles/" + uniqueID,
            aFile[0].rawFile,
            lMetaData
        );

        lUploadTask.then(async (res) => {
            const toast = await this.aToastCtrl.create({
                duration: 3000,
                message: "File upload finished!",
            });
            toast.present();
        });

        this.aFirebaseService
            .createCollection(this.hNewTopicForm.value, "Discussion")
            .then((resp) => {
                this.hNewTopicForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }

    hDismissModal(){}
}
