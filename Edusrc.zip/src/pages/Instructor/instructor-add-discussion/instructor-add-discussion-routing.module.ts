import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InstructorAddDiscussionPage } from './instructor-add-discussion.page';

const routes: Routes = [
  {
    path: '',
    component: InstructorAddDiscussionPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InstructorAddDiscussionPageRoutingModule {}
