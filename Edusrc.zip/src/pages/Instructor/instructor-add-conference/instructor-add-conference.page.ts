import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ModalController } from "@ionic/angular";
import { FirebaseService } from "src/services/firebase.service";

@Component({
    selector: "app-instructor-add-conference",
    templateUrl: "./instructor-add-conference.page.html",
    styleUrls: ["./instructor-add-conference.page.scss"],
})
export class InstructorAddConferencePage implements OnInit {
    hNewConferenceForm: FormGroup;
    hHoursValues;
    hMinutesValues;

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {}

    ngOnInit() {
        this.hNewConferenceForm = this.aFormBuilder.group({
            ConferenceName: [""],
            Date: [""],
            Time: [""],
            Message: [""],
            Minutes: [""],
            Hours: [""],
        });
    }

    async hCloseModal() {
        await this.aModalController.dismiss("close");
    }

    async hCreateCollection() {
        this.aFirebaseService
            .createCollection(this.hNewConferenceForm.value, "Conference")
            .then((resp) => {
                this.hNewConferenceForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }
}
