import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { InstructorAddConferencePage } from './instructor-add-conference.page';

describe('InstructorAddConferencePage', () => {
  let component: InstructorAddConferencePage;
  let fixture: ComponentFixture<InstructorAddConferencePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstructorAddConferencePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(InstructorAddConferencePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
