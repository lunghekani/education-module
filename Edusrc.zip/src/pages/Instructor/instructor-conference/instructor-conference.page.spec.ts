import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { InstructorConferencePage } from './instructor-conference.page';

describe('InstructorConferencePage', () => {
  let component: InstructorConferencePage;
  let fixture: ComponentFixture<InstructorConferencePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstructorConferencePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(InstructorConferencePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
