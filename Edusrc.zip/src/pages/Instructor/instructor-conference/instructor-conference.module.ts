import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";

import { IonicModule } from "@ionic/angular";

import { InstructorConferencePageRoutingModule } from "./instructor-conference-routing.module";

import { InstructorConferencePage } from "./instructor-conference.page";
import { MultiFileUploadComponentModule } from 'src/components/multi-file-upload/multi-file-upload.component.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
		InstructorConferencePageRoutingModule,
		MultiFileUploadComponentModule
    ],
    declarations: [InstructorConferencePage],
})
export class InstructorConferencePageModule {}
