import { Component, OnInit } from "@angular/core";
import { FirebaseService } from "src/services/firebase.service";
import { ModalController } from "@ionic/angular";
import { InstructorAddConferencePage } from "../instructor-add-conference/instructor-add-conference.page";

@Component({
    selector: "app-instructor-conference",
    templateUrl: "./instructor-conference.page.html",
    styleUrls: ["./instructor-conference.page.scss"],
})
export class InstructorConferencePage implements OnInit {
    hUserConferences = [];

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService
    ) {
    }

    ngOnInit() {
        this.aFirebaseService.readCollection("Conference").subscribe((data) => {
            this.hUserConferences = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    ConferenceName: aEntryContent.payload.doc.data()[
                        "ConferenceName"
                    ],
                    Join: aEntryContent.payload.doc.data()["Join"],
                    User: aEntryContent.payload.doc.data()["User"],
                    Hours: aEntryContent.payload.doc.data()["Hours"],
                    Minutes: aEntryContent.payload.doc.data()["Minutes"],
                    Date: aEntryContent.payload.doc.data()["Date"],
                };
            });
            console.log(this.hUserConferences);
        });
    }

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Conference");
    }

    hUpdateCollection(recordRow) {
        let record = {};
        record["UnitName"] = recordRow.UnitName;
        record["CourseCode"] = recordRow.CourseCode;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Conference");
    }

    async hOpenModal() {
        let lData = { message: "hello world" };
        let lModalPage = await this.aModalController.create({
            component: InstructorAddConferencePage,
            componentProps: lData,
        });
        lModalPage.present();
    }
}
