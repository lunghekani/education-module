import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InstructorConferencePage } from './instructor-conference.page';

const routes: Routes = [
  {
    path: '',
    component: InstructorConferencePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class InstructorConferencePageRoutingModule {}
