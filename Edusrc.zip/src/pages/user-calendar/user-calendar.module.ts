import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UserCalendarPageRoutingModule } from './user-calendar-routing.module';

import { UserCalendarPage } from './user-calendar.page';
import { HttpClientModule, HttpClientJsonpModule } from '@angular/common/http';
import { NgCalendarModule  } from 'ionic2-calendar';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    UserCalendarPageRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    HttpClientJsonpModule,
    NgCalendarModule
    
  ],
  declarations: [UserCalendarPage]
})
export class UserCalendarPageModule {}
