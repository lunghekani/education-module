import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UserCalendarPage } from './user-calendar.page';

const routes: Routes = [
  {
    path: '',
    component: UserCalendarPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UserCalendarPageRoutingModule {}
