import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddInstructorTrainingSessionPageRoutingModule } from './administrator-add-instructor-training-session-routing.module';

import { AdministratorAddInstructorTrainingSessionPage } from './administrator-add-instructor-training-session.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddInstructorTrainingSessionPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [AdministratorAddInstructorTrainingSessionPage]
})
export class AdministratorAddInstructorTrainingSessionPageModule {}
