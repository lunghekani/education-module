import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddInstructorTrainingSessionPage } from './administrator-add-instructor-training-session.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddInstructorTrainingSessionPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddInstructorTrainingSessionPageRoutingModule {}
