import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddInstructorTrainingSessionPage } from './administrator-add-instructor-training-session.page';

describe('AdministratorAddInstructorTrainingSessionPage', () => {
  let component: AdministratorAddInstructorTrainingSessionPage;
  let fixture: ComponentFixture<AdministratorAddInstructorTrainingSessionPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddInstructorTrainingSessionPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddInstructorTrainingSessionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
