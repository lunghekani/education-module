import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ModalController } from '@ionic/angular';
import { FirebaseService } from 'src/services/firebase.service';

@Component({
    selector: "app-administrator-add-instructor-training-session",
    templateUrl: "./administrator-add-instructor-training-session.page.html",
    styleUrls: ["./administrator-add-instructor-training-session.page.scss"],
})
export class AdministratorAddInstructorTrainingSessionPage implements OnInit {
    TrainingForm: FormGroup;
    hMinutesValues;
    hHoursValues;

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {}

    ngOnInit() {
        this.TrainingForm = this.aFormBuilder.group({
			SessionName: [""],
			SessionColor: [""],
			Date: [""],
			Time: [""],
			Capacity: [""],
			Instructor: [""],
			LocationType: [""],
			Location: [""],
			Minutes: [""],
			Hours: [""],
			Description: [""]
        });
    }

    async hCloseModal() {
        await this.aModalController.dismiss();
    }

    hCreateTraining() {
        this.aFirebaseService
            .createCollection(this.TrainingForm.value, "TrainingSession")
            .then((resp) => {
                this.TrainingForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }
}
