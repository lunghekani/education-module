import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddQCTOPracticalComponentPageRoutingModule } from './administrator-add-qctopractical-component-routing.module';

import { AdministratorAddQCTOPracticalComponentPage } from './administrator-add-qctopractical-component.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddQCTOPracticalComponentPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [AdministratorAddQCTOPracticalComponentPage]
})
export class AdministratorAddQCTOPracticalComponentPageModule {}
