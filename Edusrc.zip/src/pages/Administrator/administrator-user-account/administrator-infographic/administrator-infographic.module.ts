import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorInfographicPageRoutingModule } from './administrator-infographic-routing.module';

import { AdministratorInfographicPage } from './administrator-infographic.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorInfographicPageRoutingModule
  ],
  declarations: [AdministratorInfographicPage]
})
export class AdministratorInfographicPageModule {}
