import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";

import { Chart } from "chart.js";
import { UserService } from 'src/services/user.local.service';
import { FirebaseService } from 'src/services/firebase.service';

@Component({
    selector: "app-administrator-infographic",
    templateUrl: "./administrator-infographic.page.html",
    styleUrls: ["./administrator-infographic.page.scss"],
})
export class AdministratorInfographicPage implements OnInit {
    hLoggedInUser;
    hUserCourses = [];

    @ViewChild("hTrainingBarChart") hTrainingBarChart: ElementRef;
    @ViewChild("hCompletionPieChart") hCompletionPieChart: ElementRef;
    @ViewChild("hPassPieChart") hPassPieChart: ElementRef;

    private barChart: Chart;
    private pieCompleteChart: Chart;
    private piePassChart: Chart;

    constructor(private aUserService:UserService,
        private aFirebaseService: FirebaseService) {}

    ngOnInit() {
        this.aFirebaseService.readCollection("Course").subscribe((data) => {
            this.hUserCourses = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    CourseName: aEntryContent.payload.doc.data()["CourseName"],
                    StartDate: aEntryContent.payload.doc.data()["StartDate"],
                    FinishDate: aEntryContent.payload.doc.data()["FinishDate"],
                };
            });
            console.log(this.hUserCourses);
        });
    }

    ionViewDidEnter() {
        this.hLoggedInUser = this.aUserService.getUserName();
        this.createBarChart();
        this.createPieChart();
        this.createPiePassChart();
    }

    createBarChart() {
        this.barChart = new Chart(this.hTrainingBarChart.nativeElement, {
            type: "bar",
            data: {
                labels: ["", "", "", "", "", "", "", ""],
                datasets: [
                    {
                        label: "",
                        data: [1],
                        backgroundColor: "rgb(65, 105, 225)", // array should have same number of elements as number of dataset
                        borderColor: "rgb(65, 105, 225)", // array should have same number of elements as number of dataset
                        borderWidth: 1,
                    },
                    {
                        label: "",
                        data: [0],
                        backgroundColor: "rgb(65, 105, 185)", // array should have same number of elements as number of dataset
                        borderColor: "rgb(65, 105, 185)", // array should have same number of elements as number of dataset
                        borderWidth: 1,
                    },
                ],
            },
            options: {
                scales: {
                    yAxes: [
                        {
                            ticks: {
                                beginAtZero: true,
                            },
                        },
                    ],
                },
                height: 300,
            },
        });
    }

    createPieChart() {
        this.pieCompleteChart = new Chart(
            this.hCompletionPieChart.nativeElement,
            {
                type: "pie",
                data: {
                    datasets: [
                        {
                            data: [1,0],
                            backgroundColor: [
                                "rgb(65, 105, 225)",
                                "rgb(65, 105, 185)",
                            ],
                            hoverBackgroundColor: ["#FFCE56", "#FF6384"],
                        },
                    ],
                },
            }
        );
    }

    createPiePassChart() {
        this.pieCompleteChart = new Chart(this.hPassPieChart.nativeElement, {
            type: "pie",
            data: {
                datasets: [
                    {
                        data: [1,0],
                        backgroundColor: [
                            "rgb(65, 105, 225)",
                            "rgb(255, 99, 132)",
                        ],
                        hoverBackgroundColor: ["#FFCE56", "#FFF"],
                    },
                ],
            },
        });
    }
}
