import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorInfographicPage } from './administrator-infographic.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorInfographicPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorInfographicPageRoutingModule {}
