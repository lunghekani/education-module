import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { AdministratorProfilePage } from "./administrator-profile.page";

const routes: Routes = [
    {
        path: "",
        component: AdministratorProfilePage,
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class AdministratorProfilePageRoutingModule {}
