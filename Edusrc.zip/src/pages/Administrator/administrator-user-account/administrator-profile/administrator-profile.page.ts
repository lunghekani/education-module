import { Component, OnInit, ViewChild } from "@angular/core";
import { MultiFileUploadComponent } from "src/components/multi-file-upload/multi-file-upload.component";
import { AngularFireStorage } from "@angular/fire/storage";
import { ToastController } from "@ionic/angular";
import { FormGroup, FormBuilder } from "@angular/forms";
import { FirebaseService } from "src/services/firebase.service";
import { AngularFirestore } from "@angular/fire/firestore";
import { UserService } from "src/services/user.local.service";
import { FileUploader } from 'ng2-file-upload';

@Component({
    selector: "app-administrator-profile",
    templateUrl: "./administrator-profile.page.html",
    styleUrls: ["./administrator-profile.page.scss"],
})
export class AdministratorProfilePage implements OnInit {
    @ViewChild(MultiFileUploadComponent) aFileField: MultiFileUploadComponent;    
    public uploader: FileUploader = new FileUploader({});
    hUserForm: FormGroup;
    hUserCourses = [];
    hUserFiles = [];
    hPageSegment = "Info";
    hPersonLogo: string = "../assets/img/UserPlaceHolderLogo.png";
    private hPercentage;
    private hSnapshot;
    private hUploadedFileURL;
    private hFileSize;

    constructor(
        private aAFStorage: AngularFireStorage,
        private aToastCtrl: ToastController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder,
        private aUserService: UserService
    ) {
        this.hUserForm = this.aFormBuilder.group({
            UserName: [""],
            FirstName: [""],
            LastName: [""],
            Email: [""],
            Password: [""],
            UserBio: [""],
            TimeZone: [""],
            Language: [""],
        });
    }

    async ngOnInit() {
        let UserProfiles = [];
        this.aFirebaseService.readCollection("User").subscribe((data) => {
            UserProfiles = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    UserName: aEntryContent.payload.doc.data()["UserName"],
                    FirstName: aEntryContent.payload.doc.data()["FirstName"],
                    LastName: aEntryContent.payload.doc.data()["LastName"],
                    Email: aEntryContent.payload.doc.data()["Email"],
                    Password: aEntryContent.payload.doc.data()["Password"],
                    UserBio: aEntryContent.payload.doc.data()["UserBio"],
                    TimeZone: aEntryContent.payload.doc.data()["TimeZone"],
                    Language: aEntryContent.payload.doc.data()["Language"],
                };
            });
            console.log(UserProfiles);

            if (UserProfiles && UserProfiles.length > 0) {
                UserProfiles.forEach((UserProfile) => {
                    console.log(this.aUserService.getUserID());
                    if (UserProfile.Id == this.aUserService.getUserID()) {
                        this.hUserForm = this.aFormBuilder.group(
                            UserProfiles[0]
                        );
                    }
                });
            } 
        });

        this.aFirebaseService.readCollection("Course").subscribe((data) => {
            this.hUserCourses = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    CourseName: aEntryContent.payload.doc.data()["CourseName"],
                    StartDate: aEntryContent.payload.doc.data()["StartDate"],
                    FinishDate: aEntryContent.payload.doc.data()["FinishDate"],
                };
            });
            console.log(this.hUserCourses);
        });
    }

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Course");
    }

    hUpdateCollection(recordRow) {
        let record = {};
        record["CourseName"] = recordRow.CourseName;
        record["StartDate"] = recordRow.StartDate;
        record["FinishDate"] = recordRow.FinishDate;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Course");
    }

    upload() {
        let lFiles = this.aFileField.getFiles();
        console.log(lFiles);

        let lMetaData = new FormData();
        lMetaData.append("somekey", "some value"); // Add any other data you want to send

        lFiles.forEach((aFile) => {
            lMetaData.append("files[]", aFile.rawFile, aFile.name);

            // Create the file metadata
            var metadata = {
                contentType: "image/jpeg",
            };

            // Upload file and metadata to the object 'images/mountains.jpg'
            let uploadTask = this.aAFStorage.upload(
                "files/" + aFile.name,
                aFile,
                metadata
            );

            // Get file progress percentage
            uploadTask.percentageChanges().subscribe((change) => {
                this.hPercentage = change;
            });

            uploadTask.then(async (res) => {
                const toast = await this.aToastCtrl.create({
                    duration: 3000,
                    message: "File upload finished!",
                });
                toast.present();
            });
        });
    }

    hSubmitForm(data) {}

    hResetUserForm() {
        this.hUserForm.reset();
    }

    hChangePersonLogo(event) {
        if (event.target.files && event.target.files[0]) {
            let reader = new FileReader();

            reader.onload = (event: any) => {
                this.hPersonLogo = event.target.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    }

    hClickPersonLogo() {
        document.getElementById("UserLogoUploadFile").click();
    }
}
