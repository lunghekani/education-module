import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { IonicModule } from "@ionic/angular";

import { AdministratorProfilePageRoutingModule } from "./administrator-profile-routing.module";

import { AdministratorProfilePage } from "./administrator-profile.page";
import { MultiFileUploadComponentModule } from 'src/components/multi-file-upload/multi-file-upload.component.module';
import { FileUploadModule } from 'ng2-file-upload';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        AdministratorProfilePageRoutingModule,
        ReactiveFormsModule,
        MultiFileUploadComponentModule,
        FileUploadModule
    ],
    declarations: [AdministratorProfilePage],
})
export class AdministratorProfilePageModule {}
