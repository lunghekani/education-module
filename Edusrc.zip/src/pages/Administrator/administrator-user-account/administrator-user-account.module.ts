import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorUserAccountPageRoutingModule } from './administrator-user-account-routing.module';

import { AdministratorUserAccountPage } from './administrator-user-account.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorUserAccountPageRoutingModule
  ],
  declarations: [AdministratorUserAccountPage]
})
export class AdministratorUserAccountPageModule {}
