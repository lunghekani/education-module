import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { AdministratorUserAccountPage } from "./administrator-user-account.page";
import { AdministratorInfographicPageModule } from "./administrator-infographic/administrator-infographic.module";
import { AdministratorProgressPageModule } from "./administrator-progress/administrator-progress.module";
import { AdministratorProfilePageModule } from "./administrator-profile/administrator-profile.module";

const routes: Routes = [
    {
        path: "",
        component: AdministratorUserAccountPage,
        children: [
            {
                path: "administrator-profile",
                loadChildren: () => AdministratorProfilePageModule,
            },
            {
                path: "administrator-progress",
                loadChildren: () => AdministratorProgressPageModule,
            },
            {
                path: "administrator-infographic",
                loadChildren: () => AdministratorInfographicPageModule,
            },
        ],
    },
    {
        path: "",
        redirectTo: "administrator-profile",
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class AdministratorUserAccountPageRoutingModule {}
