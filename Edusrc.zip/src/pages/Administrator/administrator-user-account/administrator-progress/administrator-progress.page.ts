import { Component, OnInit, ViewChild, ElementRef } from "@angular/core";
import { Chart } from "chart.js";
import { FirebaseService } from "src/services/firebase.service";
import { UserService } from "src/services/user.local.service";

@Component({
    selector: "app-administrator-progress",
    templateUrl: "./administrator-progress.page.html",
    styleUrls: ["./administrator-progress.page.scss"],
})
export class AdministratorProgressPage implements OnInit {
    hPageSegment = "Overview";
    hUserCourses = [];
    hUserEvents = [];
    hUser: any = {
        UserLogo: "../assets/img/UserPlaceHolderLogo.png",
        UserName: this.aUserService.getUserName(),
        Email: "",
    };

    @ViewChild("hLoginBarChart") hLoginBarChart: ElementRef;
    @ViewChild("hProgressPieChart") hProgressPieChart: ElementRef;

    private barChart: Chart;
    private pieChart: Chart;

    constructor(
        private aFirebaseService: FirebaseService,
        private aUserService: UserService
    ) {}

    ngOnInit() {
        this.aFirebaseService.readCollection("User").subscribe((data) => {
            this.hUser.Email = data.map((aEntryContent) => {
                if (
                    aEntryContent.payload.doc.id ==
                    this.aUserService.getUserID()
                ) {
                    return { Email: aEntryContent.payload.doc.data()["Email"] };
                }
            })[0].Email;
            console.log(this.hUser);
        });

        this.aFirebaseService.readCollection("Course").subscribe((data) => {
            this.hUserCourses = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    CourseName: aEntryContent.payload.doc.data()["CourseName"],
                    StartDate: aEntryContent.payload.doc.data()["StartDate"],
                    FinishDate: aEntryContent.payload.doc.data()["FinishDate"],
                };
            });
            console.log(this.hUserCourses);

            
            this.createPieChart();
        });
    }

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Course");
    }

    hUpdateCollection(recordRow) {
        let record = {};
        record["CourseName"] = recordRow.CourseName;
        record["StartDate"] = recordRow.StartDate;
        record["FinishDate"] = recordRow.FinishDate;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Course");
    }

    ionViewDidEnter() {
        this.createBarChart();
    }

    createBarChart() {
        this.barChart = new Chart(this.hLoginBarChart.nativeElement, {
            type: "bar",
            data: {
                labels: [
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                ],
                datasets: [
                    {
                        label: "",
                        data: [1, 1],
                        backgroundColor: "rgb(65, 105, 225)", // array should have same number of elements as number of dataset
                        borderColor: "rgb(65, 105, 225)", // array should have same number of elements as number of dataset
                        borderWidth: 1,
                    },
                    {
                        label: "",
                        data: [1, 1],
                        backgroundColor: "#dd1144", // array should have same number of elements as number of dataset
                        borderColor: "#dd1144", // array should have same number of elements as number of dataset
                        borderWidth: 1,
                    },
                ],
            },
            options: {
                scales: {
                    yAxes: [
                        {
                            ticks: {
                                beginAtZero: true,
                            },
                        },
                    ],
                },
                height: 300,
            },
        });
    }

    createPieChart() {
        this.pieChart = new Chart(this.hProgressPieChart.nativeElement, {
            type: "doughnut",
            data: {
                labels: ["Busy", "Completed", "Not Started"],
                datasets: [
                    {
                        data: [0.01, 0.01, this.hUserCourses.length],
                        backgroundColor: [
                            "rgba(255, 206, 86, 1)",
                            "rgba(255, 99, 132, 2)",
                            "rgba(153, 102, 255, 2)",
                        ],
                        hoverBackgroundColor: ["#FFCE56", "#FF6384", "#36A2EB"],
                    },
                ],
            },
        });
    }
}
