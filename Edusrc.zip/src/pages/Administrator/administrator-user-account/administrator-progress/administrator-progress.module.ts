import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorProgressPageRoutingModule } from './administrator-progress-routing.module';

import { AdministratorProgressPage } from './administrator-progress.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorProgressPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [AdministratorProgressPage]
})
export class AdministratorProgressPageModule {}
