import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/services/user.local.service';

@Component({
  selector: 'app-administrator-user-account',
  templateUrl: './administrator-user-account.page.html',
  styleUrls: ['./administrator-user-account.page.scss'],
})
export class AdministratorUserAccountPage implements OnInit {
  hLoggedInUser;

  constructor(private aRouter: Router, private aUserService : UserService) { }

  ngOnInit() {}

  ionViewDidEnter() {
    this.hLoggedInUser = this.aUserService.getUserName();
  }

}
