import { Component, OnInit, ViewChild } from "@angular/core";
import { ModalController, IonSelect } from "@ionic/angular";
import { NewUserRegistrationPage } from "src/pages/new-user-registration/new-user-registration.page";
import { AdministratorAddCoursePage } from "../administrator-add-course/administrator-add-course.page";
import { AdministratorAddGroupPage } from "../administrator-add-group/administrator-add-group.page";
import { AdministratorAddCategoryPage } from "../administrator-add-category/administrator-add-category.page";
import { UserService } from "src/services/user.local.service";
import { Router } from "@angular/router";

@Component({
    selector: "app-administrator-dashboard",
    templateUrl: "./administrator-dashboard.page.html",
    styleUrls: ["./administrator-dashboard.page.scss"],
})
export class AdministratorDashboardPage implements OnInit {
    hLoggedInUser;
    hHideList = true;
    hUserProfile = "Administrator";

    @ViewChild("hProfileList") hProfileSelectRef: IonSelect;

    constructor(
        private aModalController: ModalController,
        private aUserService: UserService,
        private aRouter: Router
    ) {}

    ngOnInit() {}

    ionViewWillEnter() {
        this.hLoggedInUser = this.aUserService.getUserName();
    }

    async hOpenModal(aPageName) {
        let lData = { message: "hello world" };
        let lModalPage;

        switch (aPageName) {
            case "User": {
                lModalPage = await this.aModalController.create({
                    component: NewUserRegistrationPage,
                    cssClass: "new-user-registration",
                    componentProps: { hOfficeType: "Head Office" },
                });
                lModalPage.present();

                break;
            }
            case "Course": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddCoursePage,
                    cssClass: "add-course",
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "Group": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddGroupPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "Category": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddCategoryPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
        }
    }

    hDisplayProfile(aEvent) {
        this.hProfileSelectRef.open(aEvent);
    }

    hSetProfile() {
        this.hUserProfile = this.hProfileSelectRef.value;
    }

    hRouteToUserHome() {
        switch (this.hProfileSelectRef.value) {
            case "Administrator":
                this.aRouter.navigate(["/administrator-dashboard"]);

                break;

            case "Assessor":
                this.aRouter.navigate(["/assessor-home"]);

                break;

            case "Instructor":
                this.aRouter.navigate(["/instructor-home"]);

                break;

            case "Moderator":
                this.aRouter.navigate(["/moderator-home"]);

                break;

            case "Learner":
                this.aRouter.navigate(["/learner-home"]);

                break;

            default:
                this.aRouter.navigate(["/administrator-dashboard"]);

                break;
        }
    }
}
