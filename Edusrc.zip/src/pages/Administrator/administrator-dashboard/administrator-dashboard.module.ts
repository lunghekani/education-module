import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorDashboardPageRoutingModule } from './administrator-dashboard-routing.module';

import { AdministratorDashboardPage } from './administrator-dashboard.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorDashboardPageRoutingModule
  ],
  declarations: [AdministratorDashboardPage]
})
export class AdministratorDashboardPageModule {}
