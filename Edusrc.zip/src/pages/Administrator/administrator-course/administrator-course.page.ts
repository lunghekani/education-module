import { Component, OnInit } from "@angular/core";
import { AdministratorAddCoursePage } from "../administrator-add-course/administrator-add-course.page";
import { ModalController } from "@ionic/angular";
import { FirebaseService } from "src/services/firebase.service";

@Component({
    selector: "app-administrator-course",
    templateUrl: "./administrator-course.page.html",
    styleUrls: ["./administrator-course.page.scss"],
})
export class AdministratorCoursePage implements OnInit {
    hUserCourses = [];

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService
    ) {}

    ngOnInit() {
        this.aFirebaseService.readCollection("Course").subscribe((data) => {
            this.hUserCourses = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    CourseName: aEntryContent.payload.doc.data()["CourseName"],
                    Category: aEntryContent.payload.doc.data()["Category"],
                    CourseType: aEntryContent.payload.doc.data()["CourseType"],
                    LastUpdatedOn: aEntryContent.payload.doc.data()[
                        "LastUpdatedOn"
                    ],
                    CourseOwner: aEntryContent.payload.doc.data()[
                        "CourseOwner"
                    ],
                };
            });
            console.log(this.hUserCourses);
        });
    }

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Course");
    }

    hUpdateCollection(recordRow) {
        let record = {};
        record["CourseName"] = recordRow.CourseName;
        record["Category"] = recordRow.Category;
        record["CourseType"] = recordRow.CourseType;
        record["LastUpdatedOn"] = recordRow.LastUpdatedOn;
        record["Instructor"] = recordRow.Instructor;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Course");
    }

    async hOpenModal() {
        let lData = { message: "hello world" };
        let lModalPage = await this.aModalController.create({
            component: AdministratorAddCoursePage,
            cssClass: "add-course",
            componentProps: lData,
        });

        lModalPage.present();
    }
}
