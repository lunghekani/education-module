import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administrator-course-type',
  templateUrl: './administrator-course-type.page.html',
  styleUrls: ['./administrator-course-type.page.scss'],
})
export class AdministratorCourseTypePage implements OnInit {
  hUserCourses=[];
  
  constructor() { }

  ngOnInit() {
  }

}
