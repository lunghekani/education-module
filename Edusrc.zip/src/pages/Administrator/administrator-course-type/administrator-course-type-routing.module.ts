import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorCourseTypePage } from './administrator-course-type.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorCourseTypePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorCourseTypePageRoutingModule {}
