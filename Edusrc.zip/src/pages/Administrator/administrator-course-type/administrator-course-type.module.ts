import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorCourseTypePageRoutingModule } from './administrator-course-type-routing.module';

import { AdministratorCourseTypePage } from './administrator-course-type.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorCourseTypePageRoutingModule
  ],
  declarations: [AdministratorCourseTypePage]
})
export class AdministratorCourseTypePageModule {}
