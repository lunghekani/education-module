import { Component, OnInit } from "@angular/core";
import { ModalController, ToastController } from "@ionic/angular";
import { FirebaseService } from "src/services/firebase.service";
import { FormGroup, FormBuilder } from "@angular/forms";
import { FileUploader } from "ng2-file-upload";
import { AngularFireStorage } from "@angular/fire/storage";
import { UserService } from "src/services/user.local.service";

@Component({
    selector: "app-administrator-add-course",
    templateUrl: "./administrator-add-course.page.html",
    styleUrls: ["./administrator-add-course.page.scss"],
})
export class AdministratorAddCoursePage implements OnInit {
    public uploader: FileUploader = new FileUploader({});
    hNewCourseForm: FormGroup;
    hCategories = [];
    hTypeChosen: string;
    hVideoSegment = "Youtube";

    hCourseLogo: string = "../assets/img/CoursePlaceHolderImage.jpg";

    constructor(
        private aFormBuilder: FormBuilder,
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aAFStorage: AngularFireStorage,
        private aToastCtrl: ToastController,
        private aUserService: UserService
    ) {}

    ngOnInit() {
        this.aFirebaseService.readCollection("Category").subscribe((data) => {
            this.hCategories = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    CategoryName: aEntryContent.payload.doc.data()[
                        "CategoryName"
                    ],
                };
            });
            console.log(this.hCategories);
        });

        this.hNewCourseForm = this.aFormBuilder.group({
            CourseName: [""],
            Category: this.hCategories,
            CourseCode: [""],
            CourseDescription: [""],
            Video: [""],
            TimeLimit: [""],
            Certification: [""],
            CertificationLevel: [""],
            CourseLogo: [""]
        });
    }

    async hCloseModal() {
        await this.aModalController.dismiss("close");
    }

    async hCreateCollection() {
        let aFile = await this.uploader.queue.map((fileItem) => {
            return fileItem.file;
        });

        if (aFile && aFile.length != 0) {
            for (let i = 0; i < aFile.length; i++) {
                // Create the file metadata
                let lMetaData = {
                    contentType: aFile[i].type,
                    size: aFile[i].size,
                    name: aFile[i].name,
                };

                let uniqueID: string = new Date().getTime().toString(36) + i;
                if(lMetaData.contentType.includes("image")){
                    this.hNewCourseForm.value["CourseLogo"] = uniqueID;
                } else {
                    this.hNewCourseForm.value["FileID"] = uniqueID;
                }

                // Upload file and metadata to the object 'images/mountains.jpg'
                let lUploadTask = this.aAFStorage.upload(
                    "CourseFiles/" + uniqueID,
                    aFile[i].rawFile,
                    lMetaData
                );

                lUploadTask.then(async (res) => {
                    const toast = await this.aToastCtrl.create({
                        duration: 3000,
                        message: "File upload finished!",
                    });
                    toast.present();
                });
            }
        }

        this.hNewCourseForm.value["CourseType"] = this.hTypeChosen;

        this.hNewCourseForm.value[
            "CourseOwner"
        ] = this.aUserService.getUserName();

        this.aFirebaseService
            .createCollection(this.hNewCourseForm.value, "Course")
            .then((resp) => {
                this.hNewCourseForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }

    hChangeCourseLogo(event) {
        if (event.target.files && event.target.files[0]) {
            let reader = new FileReader();

            reader.onload = (event: any) => {
                this.hCourseLogo = event.target.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    }

    hClickCourseLogo() {
        document.getElementById("CourseLogoUploadFile").click();
    }

    hChooseType(Type) {
        this.hTypeChosen = Type;
    }
}
