import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddCoursePageRoutingModule } from './administrator-add-course-routing.module';

import { AdministratorAddCoursePage } from './administrator-add-course.page';
import { FileUploadModule } from 'ng2-file-upload';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddCoursePageRoutingModule,
    ReactiveFormsModule,
    FileUploadModule
  ],
  declarations: [AdministratorAddCoursePage]
})
export class AdministratorAddCoursePageModule {}
