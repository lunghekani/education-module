import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddCoursePage } from './administrator-add-course.page';

describe('AdministratorAddCoursePage', () => {
  let component: AdministratorAddCoursePage;
  let fixture: ComponentFixture<AdministratorAddCoursePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddCoursePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddCoursePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
