import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAssessmentQCTOPracticalComponentPageRoutingModule } from './administrator-assessment-qctopractical-component-routing.module';

import { AdministratorAssessmentQCTOPracticalComponentPage } from './administrator-assessment-qctopractical-component.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAssessmentQCTOPracticalComponentPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [AdministratorAssessmentQCTOPracticalComponentPage]
})
export class AdministratorAssessmentQCTOPracticalComponentPageModule {}
