import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAssessmentQCTOPracticalComponentPage } from './administrator-assessment-qctopractical-component.page';

describe('AdministratorAssessmentQCTOPracticalComponentPage', () => {
  let component: AdministratorAssessmentQCTOPracticalComponentPage;
  let fixture: ComponentFixture<AdministratorAssessmentQCTOPracticalComponentPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAssessmentQCTOPracticalComponentPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAssessmentQCTOPracticalComponentPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
