import { Component, OnInit } from '@angular/core';
import { FormArray, FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-administrator-assessment-qctopractical-component',
  templateUrl: './administrator-assessment-qctopractical-component.page.html',
  styleUrls: ['./administrator-assessment-qctopractical-component.page.scss'],
})
export class AdministratorAssessmentQCTOPracticalComponentPage implements OnInit {
  public hPracticalComponentForm: FormGroup;

  ngOnInit() {}

  constructor(private aFormBuilder: FormBuilder) {

      this.hPracticalComponentForm = this.aFormBuilder.group({
          Title: [""],
          Code: [""],
          NQFLevel: [""],
          Credits: [""],
          Description: [""],
          ExternalDescription: [""],
          Active: [""],
          VideoLink: [""],
          RetainAccess: [""],
          TimeLimit: [""],
          Certification: [""],
          CertificationLevel: [""],
          Purpose: [""],
          Outcomes: this.aFormBuilder.array([
              this.initOutcomeFields(),
          ]),
          PhysicalRequirements: this.aFormBuilder.array([
              this.initPhysicalFields(),
          ]),
          HRRequirements: this.aFormBuilder.array([
              this.initHRFields(),
          ]),
          LegalRequirements: this.aFormBuilder.array([
              this.initLegalFields(),
          ]),
      });
  }

  initOutcomeFields(): FormGroup {
      return this.aFormBuilder.group({
          REFNumber: [""],
          Description: [""],
          Percentage: [""],
      });
  }

  addNewOutcomeField(): void {
      const control = <FormArray>this.hPracticalComponentForm.controls.Outcomes;
      control.push(this.initOutcomeFields());
}

removeOutcomeField(i: number): void {
  const control = <FormArray>this.hPracticalComponentForm.controls.Outcomes;
  control.removeAt(i);
}

  initPhysicalFields(): FormGroup {
      return this.aFormBuilder.group({
          Physical: [""],
      });
  }

  addNewPhysicalField(): void {
      const control = <FormArray>this.hPracticalComponentForm.controls.PhysicalRequirements;
      control.push(this.initPhysicalFields());
}

removePhysicalField(i: number): void {
  const control = <FormArray>this.hPracticalComponentForm.controls.PhysicalRequirements;
  control.removeAt(i);
}

  initHRFields(): FormGroup {
      return this.aFormBuilder.group({
          HR: [""],
      });
  }

  addNewHRField(): void {
      const control = <FormArray>this.hPracticalComponentForm.controls.HRRequirements;
      control.push(this.initHRFields());
}

removeHRField(i: number): void {
  const control = <FormArray>this.hPracticalComponentForm.controls.HRRequirements;
  control.removeAt(i);
}

  initLegalFields(): FormGroup {
      return this.aFormBuilder.group({
          Legal: [""],
      });
  }

  addNewLegalField(): void {
      const control = <FormArray>this.hPracticalComponentForm.controls.LegalRequirements;
      control.push(this.initLegalFields());
  }

  removeLegalField(i: number): void {
      const control = <FormArray>this.hPracticalComponentForm.controls.LegalRequirements;
      control.removeAt(i);
}

  manage(val: any): void {
      console.dir(val);
  }
}
