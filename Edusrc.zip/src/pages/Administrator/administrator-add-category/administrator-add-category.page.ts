import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ModalController } from "@ionic/angular";
import { FirebaseService } from 'src/services/firebase.service';

@Component({
    selector: "app-administrator-add-category",
    templateUrl: "./administrator-add-category.page.html",
    styleUrls: ["./administrator-add-category.page.scss"],
})
export class AdministratorAddCategoryPage implements OnInit {
    hNewCategoryForm: FormGroup;

    constructor(
        private aFormBuilder: FormBuilder,
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService
    ) {}
    ngOnInit() {
        this.hNewCategoryForm = this.aFormBuilder.group({
            CategoryName: [""],
            Category: [""],
        });
    }

    async hCloseModal() {
        await this.aModalController.dismiss("close");
    }

    async hCreateCollection() {
        this.aFirebaseService
            .createCollection(this.hNewCategoryForm.value, "Category")
            .then((resp) => {
                this.hNewCategoryForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }
}
