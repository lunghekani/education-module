import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddInstructorTrainingPageRoutingModule } from './administrator-add-instructor-training-routing.module';

import { AdministratorAddInstructorTrainingPage } from './administrator-add-instructor-training.page';
import { MbscModule } from '@mobiscroll/angular';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddInstructorTrainingPageRoutingModule,
    ReactiveFormsModule,
    MbscModule
  ],
  declarations: [AdministratorAddInstructorTrainingPage]
})
export class AdministratorAddInstructorTrainingPageModule {}
