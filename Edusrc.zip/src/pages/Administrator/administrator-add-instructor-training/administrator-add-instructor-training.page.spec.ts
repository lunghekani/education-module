import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddInstructorTrainingPage } from './administrator-add-instructor-training.page';

describe('AdministratorAddInstructorTrainingPage', () => {
  let component: AdministratorAddInstructorTrainingPage;
  let fixture: ComponentFixture<AdministratorAddInstructorTrainingPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddInstructorTrainingPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddInstructorTrainingPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
