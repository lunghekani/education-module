import { Component, OnInit } from "@angular/core";
import { mobiscroll, MbscEventcalendarOptions } from "@mobiscroll/angular";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ModalController } from "@ionic/angular";
import { FirebaseService } from "src/services/firebase.service";

@Component({
    selector: "app-administrator-add-instructor-training",
    templateUrl: "./administrator-add-instructor-training.page.html",
    styleUrls: ["./administrator-add-instructor-training.page.scss"],
})
export class AdministratorAddInstructorTrainingPage implements OnInit {
    events: any;

    eventSettings: MbscEventcalendarOptions = {
        theme: "ios",
        themeVariant: "light",
        display: "inline",
        calendarHeight: 614,
        view: {
            calendar: {
                labels: true,
            },
        },
        onEventSelect: (event, inst) => {
            mobiscroll.toast({
                message: event.event.text,
            });
        },
    };
    TrainingForm: FormGroup;
    hPageSegment = "Accept";

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {}

    ngOnInit() {
        this.TrainingForm = this.aFormBuilder.group({
            UnitName: [""],
            SkillsCourse: [""],
            SkillsCourseCode: [""],
        });
    }

    async hCloseModal() {
        await this.aModalController.dismiss();
    }

    hCreateTraining() {
        this.aFirebaseService
            .createCollection(this.TrainingForm.value, "Training")
            .then((resp) => {
                this.TrainingForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }
}
