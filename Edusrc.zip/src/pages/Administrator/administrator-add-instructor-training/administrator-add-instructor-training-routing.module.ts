import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddInstructorTrainingPage } from './administrator-add-instructor-training.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddInstructorTrainingPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddInstructorTrainingPageRoutingModule {}
