import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ModalController } from "@ionic/angular";
import { FirebaseService } from "src/services/firebase.service";

@Component({
    selector: "app-administrator-add-assignment",
    templateUrl: "./administrator-add-assignment.page.html",
    styleUrls: ["./administrator-add-assignment.page.scss"],
})
export class AdministratorAddAssignmentPage implements OnInit {
    AssignmentForm: FormGroup;
    hPageSegment = "Accept";

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {}

    ngOnInit() {
        this.AssignmentForm = this.aFormBuilder.group({
            AssignmentName: [""],
            CompletionMethod: [""],
            AssignmentDescription: [""],
        });
    }

    async hCloseModal() {
        await this.aModalController.dismiss();
    }

    hCreateAssignment() {
        this.aFirebaseService
            .createCollection(this.AssignmentForm.value, "Assignment")
            .then((resp) => {
                this.AssignmentForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }
}
