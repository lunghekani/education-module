import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddAssignmentPage } from './administrator-add-assignment.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddAssignmentPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddAssignmentPageRoutingModule {}
