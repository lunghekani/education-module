import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddGroupPage } from './administrator-add-group.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddGroupPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddGroupPageRoutingModule {}
