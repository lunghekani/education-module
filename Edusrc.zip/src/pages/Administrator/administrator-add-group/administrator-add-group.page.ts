import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ModalController } from '@ionic/angular';
import { FirebaseService } from 'src/services/firebase.service';

@Component({
  selector: 'app-administrator-add-group',
  templateUrl: './administrator-add-group.page.html',
  styleUrls: ['./administrator-add-group.page.scss'],
})
export class AdministratorAddGroupPage implements OnInit {
  hNewGroupForm: FormGroup;
  
  constructor(
      private aFormBuilder: FormBuilder,
      private aModalController: ModalController,
      private aFirebaseService: FirebaseService
  ) {}
  ngOnInit() {
      this.hNewGroupForm = this.aFormBuilder.group({
          GroupName: [""],
          Description: [""],
          GroupKey: [""],
          Redemtions: [""],
          Price: [""],

      });
  }

  async hCloseModal() {
      await this.aModalController.dismiss("close");
  }

  async hCreateCollection() {
      this.aFirebaseService
          .createCollection(this.hNewGroupForm.value, "Group")
          .then((resp) => {
              this.hNewGroupForm.reset();
          })
          .catch((error) => {
              console.log(error);
          });

      this.aModalController.dismiss("success");
  }
}
