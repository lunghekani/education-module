import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddGroupPageRoutingModule } from './administrator-add-group-routing.module';

import { AdministratorAddGroupPage } from './administrator-add-group.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddGroupPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [AdministratorAddGroupPage]
})
export class AdministratorAddGroupPageModule {}
