import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestFreeTextPage } from './administrator-add-content-test-free-text.page';

describe('AdministratorAddContentTestFreeTextPage', () => {
  let component: AdministratorAddContentTestFreeTextPage;
  let fixture: ComponentFixture<AdministratorAddContentTestFreeTextPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddContentTestFreeTextPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddContentTestFreeTextPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
