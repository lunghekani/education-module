import { Component, OnInit } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { FormBuilder, FormGroup } from "@angular/forms";
import { FirebaseService } from "src/services/firebase.service";

interface TestData {
    Answers: AnswerData[];
    TotalPoints: number;
    Question: Boolean;
}

interface AnswerData {
    Option: string;
    Text: string;
    Point: number;
}

@Component({
    selector: "app-administrator-add-content-test-free-text",
    templateUrl: "./administrator-add-content-test-free-text.page.html",
    styleUrls: ["./administrator-add-content-test-free-text.page.scss"],
})
export class AdministratorAddContentTestFreeTextPage implements OnInit {
    TestForm: FormGroup;
    hTests: AnswerData[];

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {}

    ngOnInit() {
        this.TestForm = this.aFormBuilder.group({
            Answers: [""],
            Type: ["FreeText"],
        });

        this.hTests = [
            { Text: "", Option: "", Point: 0 },
            { Text: "", Option: "", Point: 0 },
        ];
    }

    async hCloseModal() {
        await this.aModalController.dismiss();
    }

    hAddAnswer() {
        this.hTests.push({ Text: "", Option: "", Point: 0 });
    }

    hCreateTest() {
        this.TestForm.value["Answers"] = this.hTests;
        this.aFirebaseService
            .createCollection(this.TestForm.value, "Test")
            .then((resp) => {
                this.TestForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }
}
