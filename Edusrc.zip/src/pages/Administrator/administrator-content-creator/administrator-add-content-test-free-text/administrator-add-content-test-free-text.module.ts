import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { IonicModule } from "@ionic/angular";

import { AdministratorAddContentTestFreeTextPageRoutingModule } from "./administrator-add-content-test-free-text-routing.module";

import { AdministratorAddContentTestFreeTextPage } from "./administrator-add-content-test-free-text.page";
import { EditorModule } from "@tinymce/tinymce-angular";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        AdministratorAddContentTestFreeTextPageRoutingModule,
        EditorModule,
        ReactiveFormsModule
    ],
    declarations: [AdministratorAddContentTestFreeTextPage],
})
export class AdministratorAddContentTestFreeTextPageModule {}
