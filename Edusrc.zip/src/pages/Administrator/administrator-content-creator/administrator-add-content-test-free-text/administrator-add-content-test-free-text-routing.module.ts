import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddContentTestFreeTextPage } from './administrator-add-content-test-free-text.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddContentTestFreeTextPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddContentTestFreeTextPageRoutingModule {}
