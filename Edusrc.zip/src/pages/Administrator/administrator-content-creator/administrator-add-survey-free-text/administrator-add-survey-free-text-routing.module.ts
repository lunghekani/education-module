import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddSurveyFreeTextPage } from './administrator-add-survey-free-text.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddSurveyFreeTextPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddSurveyFreeTextPageRoutingModule {}
