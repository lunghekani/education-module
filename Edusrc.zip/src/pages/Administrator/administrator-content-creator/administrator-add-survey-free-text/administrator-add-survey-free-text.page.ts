import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ModalController } from '@ionic/angular';
import { FirebaseService } from 'src/services/firebase.service';

interface AnswerData {
  Option: string;
  Text: string;
  Point: number;
}

@Component({
  selector: 'app-administrator-add-survey-free-text',
  templateUrl: './administrator-add-survey-free-text.page.html',
  styleUrls: ['./administrator-add-survey-free-text.page.scss'],
})
export class AdministratorAddSurveyFreeTextPage implements OnInit {
  TestForm: FormGroup;
  hTests: AnswerData[];

  constructor(
      private aModalController: ModalController,
      private aFirebaseService: FirebaseService,
      private aFormBuilder: FormBuilder
  ) {}

  ngOnInit() {
      this.TestForm = this.aFormBuilder.group({
          Answers: [""],
          Type: ["FreeText"],
      });

      this.hTests = [
          { Text: "", Option: "", Point: 0 },
          { Text: "", Option: "", Point: 0 },
      ];
  }

  async hCloseModal() {
      await this.aModalController.dismiss();
  }

  hAddAnswer() {
      this.hTests.push({ Text: "", Option: "", Point: 0 });
  }

  hCreateTest() {
      this.TestForm.value["Answers"] = this.hTests;
      this.aFirebaseService
          .createCollection(this.TestForm.value, "SurveyQuestion")
          .then((resp) => {
              this.TestForm.reset();
          })
          .catch((error) => {
              console.log(error);
          });

      this.aModalController.dismiss("success");
  }
}
