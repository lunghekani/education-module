import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddSurveyFreeTextPageRoutingModule } from './administrator-add-survey-free-text-routing.module';

import { AdministratorAddSurveyFreeTextPage } from './administrator-add-survey-free-text.page';
import { EditorModule } from '@tinymce/tinymce-angular';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddSurveyFreeTextPageRoutingModule,
    ReactiveFormsModule,
    EditorModule
  ],
  declarations: [AdministratorAddSurveyFreeTextPage]
})
export class AdministratorAddSurveyFreeTextPageModule {}
