import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administrator-course-creator-reports',
  templateUrl: './administrator-course-creator-reports.page.html',
  styleUrls: ['./administrator-course-creator-reports.page.scss'],
})
export class AdministratorCourseCreatorReportsPage implements OnInit {
  hPageSegment = "Overview";
  constructor() { }

  ngOnInit() {
  }

}
