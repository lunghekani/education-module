import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorCourseCreatorReportsPage } from './administrator-course-creator-reports.page';

describe('AdministratorCourseCreatorReportsPage', () => {
  let component: AdministratorCourseCreatorReportsPage;
  let fixture: ComponentFixture<AdministratorCourseCreatorReportsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorCourseCreatorReportsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorCourseCreatorReportsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
