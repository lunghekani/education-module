import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { AdministratorCourseCreatorReportsPage } from "./administrator-course-creator-reports.page";

const routes: Routes = [
    {
        path: "",
        component: AdministratorCourseCreatorReportsPage,
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class AdministratorCourseCreatorReportsPageRoutingModule {}
