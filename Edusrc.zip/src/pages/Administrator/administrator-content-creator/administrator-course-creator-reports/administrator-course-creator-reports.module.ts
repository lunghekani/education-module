import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorCourseCreatorReportsPageRoutingModule } from './administrator-course-creator-reports-routing.module';

import { AdministratorCourseCreatorReportsPage } from './administrator-course-creator-reports.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorCourseCreatorReportsPageRoutingModule
  ],
  declarations: [AdministratorCourseCreatorReportsPage]
})
export class AdministratorCourseCreatorReportsPageModule {}
