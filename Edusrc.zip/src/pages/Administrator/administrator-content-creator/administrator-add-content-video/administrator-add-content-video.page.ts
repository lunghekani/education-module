import { Component, OnInit } from "@angular/core";
import { ModalController, ToastController } from "@ionic/angular";
import { FormBuilder, FormGroup } from "@angular/forms";
import { FirebaseService } from "src/services/firebase.service";
import { FileUploader } from "ng2-file-upload";
import { AngularFireStorage } from "@angular/fire/storage";

@Component({
    selector: "app-administrator-add-content-video",
    templateUrl: "./administrator-add-content-video.page.html",
    styleUrls: ["./administrator-add-content-video.page.scss"],
})
export class AdministratorAddContentVideoPage implements OnInit {
    public uploader: FileUploader = new FileUploader({});
    ContentForm: FormGroup;
    hPageSegment;
    hVideoSegment;

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder,
        private aAFStorage: AngularFireStorage,
        private aToastCtrl: ToastController
    ) {}

    ngOnInit() {
        this.ContentForm = this.aFormBuilder.group({
            UnitName: [""],
            CompletionMethod: [""],
            SegmentSelection: [""],
            VideoMethod: [""],
            VideoLocation: [""],
            TimeLimit: [""],
            Type: ["Video"],
        });
    }

    async hCloseModal() {
        await this.aModalController.dismiss("close");
    }

    async hCreateCollection() {
        let aFile = await this.uploader.queue.map((fileItem) => {
            return fileItem.file;
        });

        // Create the file metadata
        let lMetaData = {
            contentType: aFile[0].type,
            size: aFile[0].size,
            name: aFile[0].name,
        };

        if (aFile[0]) {
            let uniqueID: string = new Date().getTime().toString(36);

            this.ContentForm.value["VideoLocation"] = uniqueID;

            // Upload file and metadata to the object 'images/mountains.jpg'
            let lUploadTask = this.aAFStorage.upload(
                "VideoFiles/" + uniqueID,
                aFile[0].rawFile,
                lMetaData
            );

            lUploadTask.then(async (res) => {
                const toast = await this.aToastCtrl.create({
                    duration: 3000,
                    message: "File upload finished!",
                });
                toast.present();
            });
        }

        this.aFirebaseService
            .createCollection(this.ContentForm.value, "Content")
            .then((resp) => {
                this.ContentForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }
}
