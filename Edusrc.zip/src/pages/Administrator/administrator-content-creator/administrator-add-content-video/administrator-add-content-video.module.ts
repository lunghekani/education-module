import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentVideoPageRoutingModule } from './administrator-add-content-video-routing.module';

import { AdministratorAddContentVideoPage } from './administrator-add-content-video.page';
import { EditorModule } from '@tinymce/tinymce-angular';
import { FileUploadModule } from 'ng2-file-upload';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddContentVideoPageRoutingModule,
    EditorModule,
    ReactiveFormsModule,
    FileUploadModule
  ],
  declarations: [AdministratorAddContentVideoPage]
})
export class AdministratorAddContentVideoPageModule {}
