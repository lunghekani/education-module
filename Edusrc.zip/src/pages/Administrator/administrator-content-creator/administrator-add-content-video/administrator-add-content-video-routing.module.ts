import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddContentVideoPage } from './administrator-add-content-video.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddContentVideoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddContentVideoPageRoutingModule {}
