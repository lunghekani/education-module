import { Component, OnInit, ViewChild } from "@angular/core";
import { AngularFireStorage } from "@angular/fire/storage";
import { ToastController } from "@ionic/angular";
import { MultiFileUploadComponent } from 'src/components/multi-file-upload/multi-file-upload.component';

@Component({
    selector: "app-administrator-course-creator-files",
    templateUrl: "./administrator-course-creator-files.page.html",
    styleUrls: ["./administrator-course-creator-files.page.scss"],
})
export class AdministratorCourseCreatorFilesPage implements OnInit {
    @ViewChild(MultiFileUploadComponent) fileField: MultiFileUploadComponent;
    private hPercentage = 0;
    private hSnapshot;
    private hUploadedFileURL;
    private hFileSize;
    hUserFiles = [];

    constructor(
        private aAFStorage: AngularFireStorage,
        private aToastCtrl: ToastController
    ) {}

    ngOnInit() {}

    upload() {
        let lFiles = this.fileField.getFiles();

        lFiles.forEach((aFile) => {
            // Create the file metadata
            var metadata = {
                contentType: aFile.type,
                size: aFile.size
            };

            let uniqueID : string =  new Date().getTime().toString(36);
            // Upload file and metadata to the object 'images/mountains.jpg'
            let uploadTask = this.aAFStorage.upload(
                "files/" + uniqueID,
                aFile.rawFile,
                metadata
            );

            uploadTask.percentageChanges().subscribe((change) => {
                this.hPercentage = change;
            });

            uploadTask.then(async (res) => {
                const toast = await this.aToastCtrl.create({
                    duration: 3000,
                    message: "File upload finished!",
                });
                toast.present();
            });
        });
    }
}
