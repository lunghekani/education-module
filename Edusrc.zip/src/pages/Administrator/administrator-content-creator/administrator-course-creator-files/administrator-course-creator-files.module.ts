import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";

import { IonicModule } from "@ionic/angular";

import { AdministratorCourseCreatorFilesPageRoutingModule } from "./administrator-course-creator-files-routing.module";

import { AdministratorCourseCreatorFilesPage } from "./administrator-course-creator-files.page";
import { MultiFileUploadComponentModule } from 'src/components/multi-file-upload/multi-file-upload.component.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        AdministratorCourseCreatorFilesPageRoutingModule,
        MultiFileUploadComponentModule
    ],
    declarations: [AdministratorCourseCreatorFilesPage],
})
export class AdministratorCourseCreatorFilesPageModule {}
