import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentShowAllPage } from './administrator-add-content-show-all.page';

describe('AdministratorAddContentShowAllPage', () => {
  let component: AdministratorAddContentShowAllPage;
  let fixture: ComponentFixture<AdministratorAddContentShowAllPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddContentShowAllPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddContentShowAllPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
