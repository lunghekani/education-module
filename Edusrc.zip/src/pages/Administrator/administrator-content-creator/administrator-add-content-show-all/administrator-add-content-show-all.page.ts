import { Component, OnInit } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { AdministratorAddContentTestMultipleChoicePage } from "../administrator-add-content-test-multiple-choice/administrator-add-content-test-multiple-choice.page";
import { AdministratorAddContentTestFillTheGapPage } from "../administrator-add-content-test-fill-the-gap/administrator-add-content-test-fill-the-gap.page";
import { AdministratorAddContentTestOrderingPage } from "../administrator-add-content-test-ordering/administrator-add-content-test-ordering.page";
import { AdministratorAddContentTestDragAndDropPage } from "../administrator-add-content-test-drag-and-drop/administrator-add-content-test-drag-and-drop.page";
import { AdministratorAddContentTestFreeTextPage } from "../administrator-add-content-test-free-text/administrator-add-content-test-free-text.page";
import { AdministratorAddContentTestRandomizedPage } from "../administrator-add-content-test-randomized/administrator-add-content-test-randomized.page";
import { FirebaseService } from "src/services/firebase.service";
import { FormGroup, FormBuilder } from '@angular/forms';

interface ContentData {
    Id: string;
    Status: string;
    Type: string;
    Question: Boolean;
}

@Component({
    selector: "app-administrator-add-content-show-all",
    templateUrl: "./administrator-add-content-show-all.page.html",
    styleUrls: ["./administrator-add-content-show-all.page.scss"],
})
export class AdministratorAddContentShowAllPage implements OnInit {
    hTestOptions: FormGroup;
    hContents = [];
    hTestSegment: string = "Select";
    ContentData: ContentData;

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {
        this.ContentData = {} as ContentData;
        this.hTestOptions = this.aFormBuilder.group({
            Duration: [""],
            PassScore: [""],
            ShuffleQuestion: [""],
            ShuffleAnswer: [""],
            AllowRepetition: [""],
            MaximumAttempts: [""],
            ShowCorrectAnswer: [""],
            ShowGivenAnswer: [""],
            ShowIndicator: [""],
            ShowScore: [""],
            ShowStatisticsAfterCompletion: [""],
            HideCorrectlyAnsweredQuestions: [""],
            AllowMovement: [""],
            CheckAnswer: [""],
            AbandonIfFail: [""],
            RequireSnapshot: [""],
            RequirePassword: [""],
            TestDescription: [""],
            MessagePass: [""],
            MessageFailed: [""],
        });
    }

    ngOnInit() {
        this.aFirebaseService.readCollection("Test").subscribe((data) => {
            this.hContents = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    Question: aEntryContent.payload.doc.data()["Question"],
                    Type: aEntryContent.payload.doc.data()["Type"],
                    Answers: aEntryContent.payload.doc.data()["Answers"]
                };
            });
            console.log(this.hContents);
        });
    }

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Test");
    }

    hEditCollection(rowID){

    }

    hUpdateCollection(recordRow) {
        let record = {};
        record["Status"] = recordRow.Status;
        record["Type"] = recordRow.Type;
        record["Question"] = recordRow.Question;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Test");
    }

    async hOpenModal(aPageName) {
        let lData = { message: "hello world" };
        let lModalPage;

        switch (aPageName) {
            case "Multiplechoice": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddContentTestMultipleChoicePage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "FillintheGap": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddContentTestFillTheGapPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "Ordering": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddContentTestOrderingPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "DragandDrop": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddContentTestDragAndDropPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "FreeText": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddContentTestFreeTextPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "Randomized": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddContentTestRandomizedPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
        }
    }

    hSwitchQuestionOptions(aTestPage) {
        this.hTestSegment = aTestPage;
    }

    hCreateTest(){}
}
