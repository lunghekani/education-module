import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddContentShowAllPage } from './administrator-add-content-show-all.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddContentShowAllPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddContentShowAllPageRoutingModule {}
