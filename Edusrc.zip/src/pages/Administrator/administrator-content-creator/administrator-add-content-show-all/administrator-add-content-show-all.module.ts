import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentShowAllPageRoutingModule } from './administrator-add-content-show-all-routing.module';

import { AdministratorAddContentShowAllPage } from './administrator-add-content-show-all.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddContentShowAllPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [AdministratorAddContentShowAllPage]
})
export class AdministratorAddContentShowAllPageModule {}
