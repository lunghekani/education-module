import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestRandomizedPageRoutingModule } from './administrator-add-content-test-randomized-routing.module';

import { AdministratorAddContentTestRandomizedPage } from './administrator-add-content-test-randomized.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddContentTestRandomizedPageRoutingModule
  ],
  declarations: [AdministratorAddContentTestRandomizedPage]
})
export class AdministratorAddContentTestRandomizedPageModule {}
