import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestRandomizedPage } from './administrator-add-content-test-randomized.page';

describe('AdministratorAddContentTestRandomizedPage', () => {
  let component: AdministratorAddContentTestRandomizedPage;
  let fixture: ComponentFixture<AdministratorAddContentTestRandomizedPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddContentTestRandomizedPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddContentTestRandomizedPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
