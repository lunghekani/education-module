import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddContentTestRandomizedPage } from './administrator-add-content-test-randomized.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddContentTestRandomizedPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddContentTestRandomizedPageRoutingModule {}
