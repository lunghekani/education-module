import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administrator-add-content-test-randomized',
  templateUrl: './administrator-add-content-test-randomized.page.html',
  styleUrls: ['./administrator-add-content-test-randomized.page.scss'],
})
export class AdministratorAddContentTestRandomizedPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
