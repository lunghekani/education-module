import { Component, OnInit } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { FormGroup, FormBuilder } from "@angular/forms";
import { FirebaseService } from "src/services/firebase.service";

interface TestData {
    Answers: AnswerData[];
    Question: string;
}

interface AnswerData {
    Text: string;
    Order: number;
}

@Component({
    selector: "app-administrator-add-content-test-ordering",
    templateUrl: "./administrator-add-content-test-ordering.page.html",
    styleUrls: ["./administrator-add-content-test-ordering.page.scss"],
})
export class AdministratorAddContentTestOrderingPage implements OnInit {
    TestForm: FormGroup;
    hTests: AnswerData[];

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {}

    ngOnInit() {
        this.TestForm = this.aFormBuilder.group({
            Answers: [""],
            Type: ["Ordering"],
        });

        this.hTests = [
            { Text: "", Order: 0 },
            { Text: "", Order: 1 },
        ];
    }

    async hCloseModal() {
        await this.aModalController.dismiss();
    }

    hAddAnswer() {
        this.hTests.push({ Text: "", Order: 1 });
    }

    hCreateTest() {
        this.TestForm.value["Answers"] = this.hTests;
        this.aFirebaseService
            .createCollection(this.TestForm.value, "Test")
            .then((resp) => {
                this.TestForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }

    hReOrderFiles(event){
        
    }
}
