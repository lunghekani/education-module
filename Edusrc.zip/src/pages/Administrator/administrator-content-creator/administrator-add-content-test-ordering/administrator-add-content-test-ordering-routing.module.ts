import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddContentTestOrderingPage } from './administrator-add-content-test-ordering.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddContentTestOrderingPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddContentTestOrderingPageRoutingModule {}
