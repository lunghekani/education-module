import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestOrderingPage } from './administrator-add-content-test-ordering.page';

describe('AdministratorAddContentTestOrderingPage', () => {
  let component: AdministratorAddContentTestOrderingPage;
  let fixture: ComponentFixture<AdministratorAddContentTestOrderingPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddContentTestOrderingPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddContentTestOrderingPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
