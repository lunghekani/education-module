import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { IonicModule } from "@ionic/angular";

import { AdministratorAddContentPageRoutingModule } from "./administrator-add-content-routing.module";

import { AdministratorAddContentPage } from "./administrator-add-content.page";
import { EditorModule } from "@tinymce/tinymce-angular";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        IonicModule,
        AdministratorAddContentPageRoutingModule,
        EditorModule,
        ReactiveFormsModule
    ],
    declarations: [AdministratorAddContentPage],
})
export class AdministratorAddContentPageModule {}
