import { Component, OnInit, Input } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { FirebaseService } from "src/services/firebase.service";

interface ContentData {
    UnitName: string;
    CompletionMethod: string;
    Question: Boolean;
    Checkbox: boolean;
    Time: string;
    Text: string;
}

@Component({
    selector: "app-administrator-add-content",
    templateUrl: "./administrator-add-content.page.html",
    styleUrls: ["./administrator-add-content.page.scss"],
})
export class AdministratorAddContentPage implements OnInit {
    // Data passed in by componentProps
    @Input() firstName: string;
    @Input() lastName: string;
    @Input() middleInitial: string;

    ContentForm: FormGroup;
    hPageSegment;

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {}

    ngOnInit() {
        this.ContentForm = this.aFormBuilder.group({
            UnitName: [""],
            CompletionMethod: [""],
            SegmentSelection: [""],
            TimeLimit: [""],
            Type: ["Content"]
        });
    }

    async hCloseModal() {
        await this.aModalController.dismiss("close");
    }

    hCreateCollection() {
        this.aFirebaseService
            .createCollection(this.ContentForm.value, "Content")
            .then((resp) => {
                this.ContentForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

            this.aModalController.dismiss("success");
    }
}
