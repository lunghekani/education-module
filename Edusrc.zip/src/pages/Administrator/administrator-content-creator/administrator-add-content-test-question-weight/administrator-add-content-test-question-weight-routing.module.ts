import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddContentTestQuestionWeightPage } from './administrator-add-content-test-question-weight.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddContentTestQuestionWeightPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddContentTestQuestionWeightPageRoutingModule {}
