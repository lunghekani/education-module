import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administrator-add-content-test-question-weight',
  templateUrl: './administrator-add-content-test-question-weight.page.html',
  styleUrls: ['./administrator-add-content-test-question-weight.page.scss'],
})
export class AdministratorAddContentTestQuestionWeightPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
