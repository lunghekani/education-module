import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestQuestionWeightPage } from './administrator-add-content-test-question-weight.page';

describe('AdministratorAddContentTestQuestionWeightPage', () => {
  let component: AdministratorAddContentTestQuestionWeightPage;
  let fixture: ComponentFixture<AdministratorAddContentTestQuestionWeightPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddContentTestQuestionWeightPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddContentTestQuestionWeightPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
