import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestQuestionWeightPageRoutingModule } from './administrator-add-content-test-question-weight-routing.module';

import { AdministratorAddContentTestQuestionWeightPage } from './administrator-add-content-test-question-weight.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddContentTestQuestionWeightPageRoutingModule
  ],
  declarations: [AdministratorAddContentTestQuestionWeightPage]
})
export class AdministratorAddContentTestQuestionWeightPageModule {}
