import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentPresentationPageRoutingModule } from './administrator-add-content-presentation-routing.module';

import { AdministratorAddContentPresentationPage } from './administrator-add-content-presentation.page';
import { EditorModule } from '@tinymce/tinymce-angular';
import { FileUploadModule } from 'ng2-file-upload';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddContentPresentationPageRoutingModule,
    EditorModule,
    ReactiveFormsModule,
    FileUploadModule
  ],
  declarations: [AdministratorAddContentPresentationPage]
})
export class AdministratorAddContentPresentationPageModule {}
