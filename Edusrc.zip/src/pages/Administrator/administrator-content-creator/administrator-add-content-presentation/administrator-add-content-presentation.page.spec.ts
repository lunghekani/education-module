import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentPresentationPage } from './administrator-add-content-presentation.page';

describe('AdministratorAddContentPresentationPage', () => {
  let component: AdministratorAddContentPresentationPage;
  let fixture: ComponentFixture<AdministratorAddContentPresentationPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddContentPresentationPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddContentPresentationPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
