import { Component, OnInit } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { FormBuilder, FormGroup } from "@angular/forms";
import { FirebaseService } from "src/services/firebase.service";
import { FileUploader } from "ng2-file-upload";

@Component({
    selector: "app-administrator-add-content-presentation",
    templateUrl: "./administrator-add-content-presentation.page.html",
    styleUrls: ["./administrator-add-content-presentation.page.scss"],
})
export class AdministratorAddContentPresentationPage implements OnInit {
    public uploader: FileUploader = new FileUploader({});
    ContentForm: FormGroup;
    hPageSegment;

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {}

    ngOnInit() {
        this.ContentForm = this.aFormBuilder.group({
            UnitName: [""],
            CompletionMethod: [""],
            SegmentSelection: [""],
            TimeLimit: [""],
            Type: ["Presentation"],
        });
    }

    async hCloseModal() {
        await this.aModalController.dismiss("close");
    }

    hCreateCollection() {
        this.aFirebaseService
            .createCollection(this.ContentForm.value, "Content")
            .then((resp) => {
                this.ContentForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }
}
