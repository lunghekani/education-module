import { Component, OnInit } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { AdministratorAddContentPage } from "../administrator-add-content/administrator-add-content.page";
import { AdministratorAddContentVideoPage } from "../administrator-add-content-video/administrator-add-content-video.page";
import { AdministratorAddContentAudioPage } from "../administrator-add-content-audio/administrator-add-content-audio.page";
import { AdministratorAddContentPresentationPage } from "../administrator-add-content-presentation/administrator-add-content-presentation.page";
import { AdministratorAddContentTestPage } from "../administrator-add-content-test/administrator-add-content-test.page";
import { AdministratorAddContentWebPage } from "../administrator-add-content-web/administrator-add-content-web.page";
import { FirebaseService } from "src/services/firebase.service";

interface ContentData {
    Id: string;
    UnitName: string;
    CompletionMethod: string;
    Question: Boolean;
    Checkbox: boolean;
    Time: string;
    Text: string;
}

@Component({
    selector: "app-administrator-course-creator-content",
    templateUrl: "./administrator-course-creator-content.page.html",
    styleUrls: ["./administrator-course-creator-content.page.scss"],
})
export class AdministratorCourseCreatorContentPage implements OnInit {
    hContents = [];
    ContentData: ContentData;

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService
    ) {
        this.ContentData = {} as ContentData;
    }

    ngOnInit() {
        this.aFirebaseService.readCollection("Content").subscribe((data) => {
            this.hContents = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    UnitName: aEntryContent.payload.doc.data()["UnitName"],
                    CompletionMethod: aEntryContent.payload.doc.data()[
                        "CompletionMethod"
                    ],
                    SegmentSelection: aEntryContent.payload.doc.data()["SegmentSelection"],
                    TimeLimit: aEntryContent.payload.doc.data()["TimeLimit"],
                    TextArea: aEntryContent.payload.doc.data()["TextArea"],
                    Type: aEntryContent.payload.doc.data()["Type"]
                };
            });
            console.log(this.hContents);
        });
    }

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Content");
    }

    hUpdateCollection(recordRow?) {
        let record = {};
        record["UnitName"] = recordRow.UnitName;
        record["CompletionMethod"] = recordRow.CompletionMethod;
        record["Question"] = recordRow.Question;
        record["Checkbox"] = recordRow.Checkbox;
        record["Time"] = recordRow.Time;
        record["Text"] = recordRow.Text;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Content");
    }

    async hOpenModal(aPageName) {
        let lData = { message: "hello world" };
        let lModalPage;

        switch (aPageName) {
            case "Content": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddContentPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "WebContent": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddContentWebPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "Video": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddContentVideoPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "Audio": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddContentAudioPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "Presentation": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddContentPresentationPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "Skills": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddContentTestPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "Test": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddContentTestPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
        }
    }
}
