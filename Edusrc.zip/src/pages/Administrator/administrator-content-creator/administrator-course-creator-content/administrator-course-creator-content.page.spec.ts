import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorCourseCreatorContentPage } from './administrator-course-creator-content.page';

describe('AdministratorCourseCreatorContentPage', () => {
  let component: AdministratorCourseCreatorContentPage;
  let fixture: ComponentFixture<AdministratorCourseCreatorContentPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorCourseCreatorContentPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorCourseCreatorContentPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
