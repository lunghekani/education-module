import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorCourseCreatorContentPageRoutingModule } from './administrator-course-creator-content-routing.module';

import { AdministratorCourseCreatorContentPage } from './administrator-course-creator-content.page';

import { AdministratorAddContentPageModule } from '../administrator-add-content/administrator-add-content.module';
import { AdministratorAddContentVideoPageModule } from '../administrator-add-content-video/administrator-add-content-video.module';
import { AdministratorAddContentAudioPageModule } from '../administrator-add-content-audio/administrator-add-content-audio.module';
import { AdministratorAddContentPresentationPageModule } from '../administrator-add-content-presentation/administrator-add-content-presentation.module';
import { AdministratorAddContentTestPageModule } from '../administrator-add-content-test/administrator-add-content-test.module';
import { AdministratorAddContentWebPageModule } from '../administrator-add-content-web/administrator-add-content-web.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorCourseCreatorContentPageRoutingModule,
    AdministratorAddContentPageModule,
    AdministratorAddContentVideoPageModule,
    AdministratorAddContentAudioPageModule,
    AdministratorAddContentPresentationPageModule,
    AdministratorAddContentTestPageModule,
    AdministratorAddContentWebPageModule
  ],
  declarations: [AdministratorCourseCreatorContentPage]
})
export class AdministratorCourseCreatorContentPageModule {}
