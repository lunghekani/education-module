import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorCourseCreatorContentPage } from './administrator-course-creator-content.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorCourseCreatorContentPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorCourseCreatorContentPageRoutingModule {}
