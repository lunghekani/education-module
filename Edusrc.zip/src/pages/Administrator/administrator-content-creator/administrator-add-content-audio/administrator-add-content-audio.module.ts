import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentAudioPageRoutingModule } from './administrator-add-content-audio-routing.module';

import { AdministratorAddContentAudioPage } from './administrator-add-content-audio.page';
import { EditorModule } from '@tinymce/tinymce-angular';
import { FileUploadModule } from 'ng2-file-upload';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddContentAudioPageRoutingModule,
    EditorModule,
    ReactiveFormsModule,
    FileUploadModule
  ],
  declarations: [AdministratorAddContentAudioPage]
})
export class AdministratorAddContentAudioPageModule {}
