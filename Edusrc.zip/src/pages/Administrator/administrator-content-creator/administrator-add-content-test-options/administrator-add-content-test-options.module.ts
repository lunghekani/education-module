import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestOptionsPageRoutingModule } from './administrator-add-content-test-options-routing.module';

import { AdministratorAddContentTestOptionsPage } from './administrator-add-content-test-options.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddContentTestOptionsPageRoutingModule
  ],
  declarations: [AdministratorAddContentTestOptionsPage]
})
export class AdministratorAddContentTestOptionsPageModule {}
