import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddContentTestOptionsPage } from './administrator-add-content-test-options.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddContentTestOptionsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddContentTestOptionsPageRoutingModule {}
