import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administrator-add-content-test-options',
  templateUrl: './administrator-add-content-test-options.page.html',
  styleUrls: ['./administrator-add-content-test-options.page.scss'],
})
export class AdministratorAddContentTestOptionsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
