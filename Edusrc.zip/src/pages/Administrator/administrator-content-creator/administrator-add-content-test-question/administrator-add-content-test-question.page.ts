import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administrator-add-content-test-question',
  templateUrl: './administrator-add-content-test-question.page.html',
  styleUrls: ['./administrator-add-content-test-question.page.scss'],
})
export class AdministratorAddContentTestQuestionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
