import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddContentTestQuestionPage } from './administrator-add-content-test-question.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddContentTestQuestionPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddContentTestQuestionPageRoutingModule {}
