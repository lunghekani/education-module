import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestQuestionPageRoutingModule } from './administrator-add-content-test-question-routing.module';

import { AdministratorAddContentTestQuestionPage } from './administrator-add-content-test-question.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddContentTestQuestionPageRoutingModule
  ],
  declarations: [AdministratorAddContentTestQuestionPage]
})
export class AdministratorAddContentTestQuestionPageModule {}
