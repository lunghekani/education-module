import { Component, OnInit } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { FormGroup, FormBuilder } from "@angular/forms";
import { FirebaseService } from "src/services/firebase.service";

@Component({
    selector: "app-administrator-add-content-test-fill-the-gap",
    templateUrl: "./administrator-add-content-test-fill-the-gap.page.html",
    styleUrls: ["./administrator-add-content-test-fill-the-gap.page.scss"],
})
export class AdministratorAddContentTestFillTheGapPage implements OnInit {
    TestForm: FormGroup;

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {}

    ngOnInit() {
        this.TestForm = this.aFormBuilder.group({
            Type: ["FillInTheGap"],
        });
    }

    async hCloseModal() {
        await this.aModalController.dismiss();
    }

    hCreateTest() {
        this.aFirebaseService
            .createCollection(this.TestForm.value, "Test")
            .then((resp) => {
                this.TestForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }
}
