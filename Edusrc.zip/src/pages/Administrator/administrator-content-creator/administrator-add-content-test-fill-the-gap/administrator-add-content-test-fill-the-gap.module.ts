import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestFillTheGapPageRoutingModule } from './administrator-add-content-test-fill-the-gap-routing.module';

import { AdministratorAddContentTestFillTheGapPage } from './administrator-add-content-test-fill-the-gap.page';
import { EditorModule } from '@tinymce/tinymce-angular';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddContentTestFillTheGapPageRoutingModule,
    EditorModule,
    ReactiveFormsModule
  ],
  declarations: [AdministratorAddContentTestFillTheGapPage]
})
export class AdministratorAddContentTestFillTheGapPageModule {}
