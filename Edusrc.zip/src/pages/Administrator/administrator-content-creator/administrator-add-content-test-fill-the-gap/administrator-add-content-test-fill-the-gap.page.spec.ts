import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestFillTheGapPage } from './administrator-add-content-test-fill-the-gap.page';

describe('AdministratorAddContentTestFillTheGapPage', () => {
  let component: AdministratorAddContentTestFillTheGapPage;
  let fixture: ComponentFixture<AdministratorAddContentTestFillTheGapPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddContentTestFillTheGapPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddContentTestFillTheGapPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
