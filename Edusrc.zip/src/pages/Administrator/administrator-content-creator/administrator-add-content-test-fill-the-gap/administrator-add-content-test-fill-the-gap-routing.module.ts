import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddContentTestFillTheGapPage } from './administrator-add-content-test-fill-the-gap.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddContentTestFillTheGapPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddContentTestFillTheGapPageRoutingModule {}
