import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddContentTestDragAndDropPage } from './administrator-add-content-test-drag-and-drop.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddContentTestDragAndDropPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddContentTestDragAndDropPageRoutingModule {}
