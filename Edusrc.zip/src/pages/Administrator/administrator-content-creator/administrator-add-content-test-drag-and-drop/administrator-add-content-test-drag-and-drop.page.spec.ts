import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestDragAndDropPage } from './administrator-add-content-test-drag-and-drop.page';

describe('AdministratorAddContentTestDragAndDropPage', () => {
  let component: AdministratorAddContentTestDragAndDropPage;
  let fixture: ComponentFixture<AdministratorAddContentTestDragAndDropPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddContentTestDragAndDropPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddContentTestDragAndDropPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
