import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestDragAndDropPageRoutingModule } from './administrator-add-content-test-drag-and-drop-routing.module';

import { AdministratorAddContentTestDragAndDropPage } from './administrator-add-content-test-drag-and-drop.page';
import { EditorModule } from '@tinymce/tinymce-angular';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddContentTestDragAndDropPageRoutingModule,
    EditorModule,
    ReactiveFormsModule
  ],
  declarations: [AdministratorAddContentTestDragAndDropPage]
})
export class AdministratorAddContentTestDragAndDropPageModule {}
