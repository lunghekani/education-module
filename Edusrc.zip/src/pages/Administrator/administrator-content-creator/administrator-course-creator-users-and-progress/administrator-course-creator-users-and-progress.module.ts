import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorCourseCreatorUsersAndProgressPageRoutingModule } from './administrator-course-creator-users-and-progress-routing.module';

import { AdministratorCourseCreatorUsersAndProgressPage } from './administrator-course-creator-users-and-progress.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorCourseCreatorUsersAndProgressPageRoutingModule,ReactiveFormsModule
  ],
  declarations: [AdministratorCourseCreatorUsersAndProgressPage]
})
export class AdministratorCourseCreatorUsersAndProgressPageModule {}
