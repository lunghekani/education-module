import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorCourseCreatorUsersAndProgressPage } from './administrator-course-creator-users-and-progress.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorCourseCreatorUsersAndProgressPage,
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorCourseCreatorUsersAndProgressPageRoutingModule {}
