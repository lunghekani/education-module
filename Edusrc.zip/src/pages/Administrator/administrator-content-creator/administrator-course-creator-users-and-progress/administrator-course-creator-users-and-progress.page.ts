import { Component, OnInit } from '@angular/core';
import { FirebaseService } from 'src/services/firebase.service';

@Component({
  selector: 'app-administrator-course-creator-users-and-progress',
  templateUrl: './administrator-course-creator-users-and-progress.page.html',
  styleUrls: ['./administrator-course-creator-users-and-progress.page.scss'],
})
export class AdministratorCourseCreatorUsersAndProgressPage implements OnInit {
  hUserForm = [];
  hPageSegment = "CourseUsers";


  constructor(

      private aFirebaseService: FirebaseService,
  ) {}

  ngOnInit() {
    this.aFirebaseService.readCollection("User").subscribe((data) => {
      this.hUserForm = data.map((aEntryContent) => {
            return {
                Id: aEntryContent.payload.doc.id,
                UserName: aEntryContent.payload.doc.data()["UserName"],
                FirstName: aEntryContent.payload.doc.data()["FirstName"],
                LastName: aEntryContent.payload.doc.data()["LastName"],
                Email: aEntryContent.payload.doc.data()["Email"],
                Password: aEntryContent.payload.doc.data()["Password"],
                UserBio: aEntryContent.payload.doc.data()["UserBio"],
                TimeZone: aEntryContent.payload.doc.data()["TimeZone"],
                Language: aEntryContent.payload.doc.data()["Language"],
            };
        });
      })
  }

}
