import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorCourseCreatorUsersAndProgressPage } from './administrator-course-creator-users-and-progress.page';

describe('AdministratorCourseCreatorUsersAndProgressPage', () => {
  let component: AdministratorCourseCreatorUsersAndProgressPage;
  let fixture: ComponentFixture<AdministratorCourseCreatorUsersAndProgressPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorCourseCreatorUsersAndProgressPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorCourseCreatorUsersAndProgressPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
