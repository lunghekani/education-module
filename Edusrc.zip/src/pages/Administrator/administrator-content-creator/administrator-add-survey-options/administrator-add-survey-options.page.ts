import { Component, OnInit } from "@angular/core";
import { AdministratorAddSurveyMultipleChoicePage } from "../administrator-add-survey-multiple-choice/administrator-add-survey-multiple-choice.page";
import { AdministratorAddSurveyFreeTextPage } from "../administrator-add-survey-free-text/administrator-add-survey-free-text.page";
import { FormGroup, FormBuilder } from "@angular/forms";
import { ModalController } from "@ionic/angular";
import { FirebaseService } from "src/services/firebase.service";

@Component({
    selector: "app-administrator-add-survey-options",
    templateUrl: "./administrator-add-survey-options.page.html",
    styleUrls: ["./administrator-add-survey-options.page.scss"],
})
export class AdministratorAddSurveyOptionsPage implements OnInit {
    hSurveyOptions: FormGroup;
    hContents = [];
    hTestSegment: string = "Select";

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {
        this.hSurveyOptions = this.aFormBuilder.group({
            WaitForAnswer: [""],
            SurveyDescription: [""],
            ShowAnswers: [""],
        });
    }

    ngOnInit() {
        this.aFirebaseService.readCollection("Survey").subscribe((data) => {
            this.hContents = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    Question: aEntryContent.payload.doc.data()["WaitForAnswer"],
                    Type: aEntryContent.payload.doc.data()["SurveyDescription"],
                    Answers: aEntryContent.payload.doc.data()["ShowAnswers"],
                };
            });
            console.log(this.hContents);
        });
    }

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Survey");
    }

    hEditCollection(rowID) {}

    hUpdateCollection(recordRow) {
        let record = {};
        record["WaitForAnswer"] = recordRow.WaitForAnswer;
        record["SurveyDescription"] = recordRow.SurveyDescription;
        record["ShowAnswers"] = recordRow.ShowAnswers;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Survey");
    }

    async hOpenModal(aPageName) {
        let lData = { message: "hello world" };
        let lModalPage;

        switch (aPageName) {
            case "Multiplechoice": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddSurveyMultipleChoicePage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
            case "FreeText": {
                lModalPage = await this.aModalController.create({
                    component: AdministratorAddSurveyFreeTextPage,
                    componentProps: lData,
                });
                lModalPage.present();

                break;
            }
        }
    }

    hSwitchSurveyOptions(aTestPage) {
        this.hTestSegment = aTestPage;
    }

    hCreateTest() {}
}
