import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddSurveyOptionsPage } from './administrator-add-survey-options.page';

describe('AdministratorAddSurveyOptionsPage', () => {
  let component: AdministratorAddSurveyOptionsPage;
  let fixture: ComponentFixture<AdministratorAddSurveyOptionsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddSurveyOptionsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddSurveyOptionsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
