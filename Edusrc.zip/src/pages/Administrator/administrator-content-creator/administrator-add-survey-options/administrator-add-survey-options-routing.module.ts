import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddSurveyOptionsPage } from './administrator-add-survey-options.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddSurveyOptionsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddSurveyOptionsPageRoutingModule {}
