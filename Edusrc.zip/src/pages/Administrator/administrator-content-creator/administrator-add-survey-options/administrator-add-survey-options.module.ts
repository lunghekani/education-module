import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddSurveyOptionsPage } from './administrator-add-survey-options.page';
import { AdministratorAddSurveyOptionsPageRoutingModule } from './administrator-add-survey-options-routing.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddSurveyOptionsPageRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [AdministratorAddSurveyOptionsPage]
})
export class AdministratorAddSurveyOptionsPageModule {}