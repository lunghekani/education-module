import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestPageRoutingModule } from './administrator-add-content-test-routing.module';

import { AdministratorAddContentTestPage } from './administrator-add-content-test.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddContentTestPageRoutingModule
  ],
  declarations: [AdministratorAddContentTestPage]
})
export class AdministratorAddContentTestPageModule {}
