import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administrator-add-content-test',
  templateUrl: './administrator-add-content-test.page.html',
  styleUrls: ['./administrator-add-content-test.page.scss'],
})
export class AdministratorAddContentTestPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
