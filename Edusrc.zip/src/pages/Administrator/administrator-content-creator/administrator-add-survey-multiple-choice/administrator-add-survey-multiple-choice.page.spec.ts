import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddSurveyMultipleChoicePage } from './administrator-add-survey-multiple-choice.page';

describe('AdministratorAddSurveyMultipleChoicePage', () => {
  let component: AdministratorAddSurveyMultipleChoicePage;
  let fixture: ComponentFixture<AdministratorAddSurveyMultipleChoicePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddSurveyMultipleChoicePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddSurveyMultipleChoicePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
