import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddSurveyMultipleChoicePageRoutingModule } from './administrator-add-survey-multiple-choice-routing.module';

import { AdministratorAddSurveyMultipleChoicePage } from './administrator-add-survey-multiple-choice.page';
import { EditorModule } from '@tinymce/tinymce-angular';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddSurveyMultipleChoicePageRoutingModule,
    ReactiveFormsModule,
    EditorModule
  ],
  declarations: [AdministratorAddSurveyMultipleChoicePage]
})
export class AdministratorAddSurveyMultipleChoicePageModule {}
