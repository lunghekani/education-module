import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddSurveyMultipleChoicePage } from './administrator-add-survey-multiple-choice.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddSurveyMultipleChoicePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddSurveyMultipleChoicePageRoutingModule {}
