import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ModalController } from '@ionic/angular';
import { FirebaseService } from 'src/services/firebase.service';

interface AnswerData {
  Text: string;
  IsAnswer: Boolean;
}

@Component({
  selector: 'app-administrator-add-survey-multiple-choice',
  templateUrl: './administrator-add-survey-multiple-choice.page.html',
  styleUrls: ['./administrator-add-survey-multiple-choice.page.scss'],
})
export class AdministratorAddSurveyMultipleChoicePage implements OnInit {
  TestForm: FormGroup;
    hTests: AnswerData[];

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {}

    ngOnInit() {
        this.TestForm = this.aFormBuilder.group({
            Answers: [""],
            Type: ["MultipleChoice"],
        });

        this.hTests = [
            { Text: "", IsAnswer: false },
            { Text: "", IsAnswer: false },
            { Text: "", IsAnswer: false },
        ];
    }

    async hCloseModal() {
        await this.aModalController.dismiss();
    }

    hAddAnswer() {
        this.hTests.push({ Text: "", IsAnswer: false });
    }

    hCreateTest() {
        this.TestForm.value["Answers"] = this.hTests;
        this.aFirebaseService
            .createCollection(this.TestForm.value, "SurveyQuestion")
            .then((resp) => {
                this.TestForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }
}
