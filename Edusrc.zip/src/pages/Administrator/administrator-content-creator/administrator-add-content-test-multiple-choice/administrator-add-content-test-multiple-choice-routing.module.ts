import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddContentTestMultipleChoicePage } from './administrator-add-content-test-multiple-choice.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddContentTestMultipleChoicePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddContentTestMultipleChoicePageRoutingModule {}
