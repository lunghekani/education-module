import { Component, OnInit } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { FormGroup, FormBuilder } from "@angular/forms";
import { FirebaseService } from "src/services/firebase.service";

interface TestData {
    Answers: AnswerData[];
    Question: Boolean;
}

interface AnswerData {
    Text: string;
    IsAnswer: Boolean;
}

@Component({
    selector: "app-administrator-add-content-test-multiple-choice",
    templateUrl: "./administrator-add-content-test-multiple-choice.page.html",
    styleUrls: ["./administrator-add-content-test-multiple-choice.page.scss"],
})
export class AdministratorAddContentTestMultipleChoicePage implements OnInit {
    TestForm: FormGroup;
    hTests: AnswerData[];

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {}

    ngOnInit() {
        this.TestForm = this.aFormBuilder.group({
            Answers: [""],
            Type: ["MultipleChoice"],
        });

        this.hTests = [
            { Text: "", IsAnswer: false },
            { Text: "", IsAnswer: false },
            { Text: "", IsAnswer: false },
        ];
    }

    async hCloseModal() {
        await this.aModalController.dismiss();
    }

    hAddAnswer() {
        this.hTests.push({ Text: "", IsAnswer: false });
    }

    hCreateTest() {
        this.TestForm.value["Answers"] = this.hTests;
        this.aFirebaseService
            .createCollection(this.TestForm.value, "Test")
            .then((resp) => {
                this.TestForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }
}
