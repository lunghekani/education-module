import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestMultipleChoicePage } from './administrator-add-content-test-multiple-choice.page';

describe('AdministratorAddContentTestMultipleChoicePage', () => {
  let component: AdministratorAddContentTestMultipleChoicePage;
  let fixture: ComponentFixture<AdministratorAddContentTestMultipleChoicePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddContentTestMultipleChoicePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddContentTestMultipleChoicePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
