import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentTestMultipleChoicePageRoutingModule } from './administrator-add-content-test-multiple-choice-routing.module';

import { AdministratorAddContentTestMultipleChoicePage } from './administrator-add-content-test-multiple-choice.page';
import { EditorModule } from '@tinymce/tinymce-angular';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddContentTestMultipleChoicePageRoutingModule,
    EditorModule,
    ReactiveFormsModule
  ],
  declarations: [AdministratorAddContentTestMultipleChoicePage]
})
export class AdministratorAddContentTestMultipleChoicePageModule {}
