import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorContentCreatorPageRoutingModule } from './administrator-content-creator-routing.module';

import { AdministratorContentCreatorPage } from './administrator-content-creator.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorContentCreatorPageRoutingModule
  ],
  declarations: [AdministratorContentCreatorPage]
})
export class AdministratorContentCreatorPageModule {}
