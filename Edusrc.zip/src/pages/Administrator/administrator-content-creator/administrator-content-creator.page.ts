import { Component, OnInit, ViewChild } from '@angular/core';
import { IonTabs } from '@ionic/angular';

@Component({
  selector: 'app-administrator-content-creator',
  templateUrl: './administrator-content-creator.page.html',
  styleUrls: ['./administrator-content-creator.page.scss'],
})
export class AdministratorContentCreatorPage implements OnInit {
  @ViewChild("hContentCreatorTabs") hContentCreatorTab : IonTabs;
  hCompanyLogo: string = "../assets/img/CoursePlaceHolderImage.jpg";

  constructor() { }

  ngOnInit() {
    //this.hContentCreatorTab.select("administrator-course-creator-files");
  }

}
