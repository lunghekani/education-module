import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { AdministratorContentCreatorPage } from "./administrator-content-creator.page";
import { AdministratorCourseCreatorUsersAndProgressPageModule } from "./administrator-course-creator-users-and-progress/administrator-course-creator-users-and-progress.module";
import { AdministratorCourseCreatorContentPageModule } from "./administrator-course-creator-content/administrator-course-creator-content.module";
import { AdministratorCourseCreatorFilesPageModule } from "./administrator-course-creator-files/administrator-course-creator-files.module";
import { AdministratorCourseCreatorReportsPageModule } from "./administrator-course-creator-reports/administrator-course-creator-reports.module";
import { AdministratorAddContentPageModule } from "./administrator-add-content/administrator-add-content.module";
import { AdministratorAddContentVideoPageModule } from "./administrator-add-content-video/administrator-add-content-video.module";
import { AdministratorAddContentAudioPageModule } from "./administrator-add-content-audio/administrator-add-content-audio.module";
import { AdministratorAddContentPresentationPageModule } from "./administrator-add-content-presentation/administrator-add-content-presentation.module";
import { AdministratorAddContentTestPageModule } from "./administrator-add-content-test/administrator-add-content-test.module";
import { AdministratorAddContentTestQuestionPageModule } from "./administrator-add-content-test-question/administrator-add-content-test-question.module";
import { AdministratorAddContentTestQuestionWeightPageModule } from "./administrator-add-content-test-question-weight/administrator-add-content-test-question-weight.module";
import { AdministratorAddContentTestOptionsPageModule } from "./administrator-add-content-test-options/administrator-add-content-test-options.module";
import { AdministratorAddContentTestMultipleChoicePageModule } from "./administrator-add-content-test-multiple-choice/administrator-add-content-test-multiple-choice.module";
import { AdministratorAddContentTestFillTheGapPageModule } from "./administrator-add-content-test-fill-the-gap/administrator-add-content-test-fill-the-gap.module";
import { AdministratorAddContentTestOrderingPageModule } from "./administrator-add-content-test-ordering/administrator-add-content-test-ordering.module";
import { AdministratorAddContentTestDragAndDropPageModule } from "./administrator-add-content-test-drag-and-drop/administrator-add-content-test-drag-and-drop.module";
import { AdministratorAddContentTestFreeTextPageModule } from "./administrator-add-content-test-free-text/administrator-add-content-test-free-text.module";
import { AdministratorAddContentShowAllPageModule } from "./administrator-add-content-show-all/administrator-add-content-show-all.module";
import { AdministratorAddSurveyOptionsPageModule } from './administrator-add-survey-options/administrator-add-survey-options.module';
import { AdministratorAddSurveyMultipleChoicePageModule } from './administrator-add-survey-multiple-choice/administrator-add-survey-multiple-choice.module';
import { AdministratorAddSurveyFreeTextPageModule } from './administrator-add-survey-free-text/administrator-add-survey-free-text.module';

const routes: Routes = [
    {
        path: "",
        component: AdministratorContentCreatorPage,
        children: [
            {
                path: "administrator-course-creator-content",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorCourseCreatorContentPageModule,
                    },
                ],
            },
            {
                path: "administrator-course-creator-users-and-progress",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorCourseCreatorUsersAndProgressPageModule,
                    },
                ],
            },
            {
                path: "administrator-course-creator-files",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorCourseCreatorFilesPageModule,
                    },
                ],
            },
            {
                path: "administrator-course-creator-reports",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorCourseCreatorReportsPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content",
                children: [
                    {
                        path: "",
                        loadChildren: () => AdministratorAddContentPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content-video",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddContentVideoPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content-audio",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddContentAudioPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content-presentation",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddContentPresentationPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content-test",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddContentTestPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content-test-question",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddContentTestQuestionPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content-test-question-weight",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddContentTestQuestionWeightPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content-test-options",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddContentTestOptionsPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content-test-multiple-choice",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddContentTestMultipleChoicePageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content-test-fill-the-gap",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddContentTestFillTheGapPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content-test-ordering",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddContentTestOrderingPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content-test-drag-and-drop",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddContentTestDragAndDropPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content-test-free-text",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddContentTestFreeTextPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-content-show-all",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddContentShowAllPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-survey-multiple-choice",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddSurveyMultipleChoicePageModule,
                    },
                ],
            },
            {
                path: "administrator-add-survey-options",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddSurveyOptionsPageModule,
                    },
                ],
            },
            {
                path: "administrator-add-survey-free-text",
                children: [
                    {
                        path: "",
                        loadChildren: () =>
                            AdministratorAddSurveyFreeTextPageModule,
                    },
                ],
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class AdministratorContentCreatorPageRoutingModule {}
