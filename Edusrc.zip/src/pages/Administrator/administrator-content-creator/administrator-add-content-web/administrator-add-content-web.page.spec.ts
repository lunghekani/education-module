import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentWebPage } from './administrator-add-content-web.page';

describe('AdministratorAddContentWebPage', () => {
  let component: AdministratorAddContentWebPage;
  let fixture: ComponentFixture<AdministratorAddContentWebPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministratorAddContentWebPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AdministratorAddContentWebPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
