import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorAddContentWebPage } from './administrator-add-content-web.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorAddContentWebPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorAddContentWebPageRoutingModule {}
