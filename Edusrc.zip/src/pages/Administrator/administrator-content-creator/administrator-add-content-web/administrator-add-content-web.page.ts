import { Component, OnInit } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { FormBuilder, FormGroup } from "@angular/forms";
import { FirebaseService } from "src/services/firebase.service";

@Component({
    selector: "app-administrator-add-content-web",
    templateUrl: "./administrator-add-content-web.page.html",
    styleUrls: ["./administrator-add-content-web.page.scss"],
})
export class AdministratorAddContentWebPage implements OnInit {
    ContentForm: FormGroup;
    hPageSegment;

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aFormBuilder: FormBuilder
    ) {}

    ngOnInit() {
        this.ContentForm = this.aFormBuilder.group({
            UnitName: [""],
            CompletionMethod: [""],
            SegmentSelection: [""],
            TimeLimit: [""],
            WebURL: [""],
            Type: ["WebContent"],
        });
    }

    async hCloseModal() {
        await this.aModalController.dismiss("close");
    }

    hCreateCollection() {
        this.aFirebaseService
            .createCollection(this.ContentForm.value, "Content")
            .then((resp) => {
                this.ContentForm.reset();
            })
            .catch((error) => {
                console.log(error);
            });

        this.aModalController.dismiss("success");
    }
}
