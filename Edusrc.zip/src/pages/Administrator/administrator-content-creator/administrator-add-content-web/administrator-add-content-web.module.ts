import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorAddContentWebPageRoutingModule } from './administrator-add-content-web-routing.module';

import { AdministratorAddContentWebPage } from './administrator-add-content-web.page';
import { EditorModule } from '@tinymce/tinymce-angular';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorAddContentWebPageRoutingModule,
    EditorModule,
    ReactiveFormsModule
  ],
  declarations: [AdministratorAddContentWebPage]
})
export class AdministratorAddContentWebPageModule {}
