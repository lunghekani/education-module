import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorCategoryPage } from './administrator-category.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorCategoryPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorCategoryPageRoutingModule {}
