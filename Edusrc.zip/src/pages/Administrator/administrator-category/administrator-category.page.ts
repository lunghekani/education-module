import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { FirebaseService } from 'src/services/firebase.service';
import { AdministratorAddCategoryPage } from '../administrator-add-category/administrator-add-category.page';

@Component({
  selector: 'app-administrator-category',
  templateUrl: './administrator-category.page.html',
  styleUrls: ['./administrator-category.page.scss'],
})
export class AdministratorCategoryPage implements OnInit {
  hContents = [];

  constructor(
      private aModalController: ModalController,
      private aFirebaseService: FirebaseService
  ) {}

  ngOnInit() {
      this.aFirebaseService.readCollection("Category").subscribe((data) => {
          this.hContents = data.map((aEntryContent) => {
              return {
                  Id: aEntryContent.payload.doc.id,
                  CategoryName: aEntryContent.payload.doc.data()["CategoryName"],
              };
          });
          console.log(this.hContents);
      });
  }

  hRemoveCollection(rowID) {
      this.aFirebaseService.deleteCollection(rowID, "Category");
  }

  hUpdateCollection(recordRow) {
      let record = {};
      record["CategoryName"] = recordRow.CategoryName;
      this.aFirebaseService.updateCollection(recordRow.Id, record, "Category");
  }

  async hOpenModal() {
      let lData = { message: "hello world" };
      let lModalPage = await this.aModalController.create({
          component: AdministratorAddCategoryPage,
          componentProps: lData,
  });
  
      lModalPage.present();
  }
}
