import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorGroupPageRoutingModule } from './administrator-group-routing.module';

import { AdministratorGroupPage } from './administrator-group.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorGroupPageRoutingModule
  ],
  declarations: [AdministratorGroupPage]
})
export class AdministratorGroupPageModule {}
