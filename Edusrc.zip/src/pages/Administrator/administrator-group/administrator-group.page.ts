import { Component, OnInit } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { FirebaseService } from "src/services/firebase.service";
import { AdministratorAddGroupPage } from "../administrator-add-group/administrator-add-group.page";

@Component({
    selector: "app-administrator-group",
    templateUrl: "./administrator-group.page.html",
    styleUrls: ["./administrator-group.page.scss"],
})
export class AdministratorGroupPage implements OnInit {
    hContents = [];

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService
    ) {}

    ngOnInit() {
        this.aFirebaseService.readCollection("Group").subscribe((data) => {
            this.hContents = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    GroupName: aEntryContent.payload.doc.data()["GroupName"],
                    GroupKey: aEntryContent.payload.doc.data()["GroupKey"],
                    GroupPrice: aEntryContent.payload.doc.data()["GroupPrice"],
                };
            });
            console.log(this.hContents);
        });
    }

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Group");
    }

    hUpdateCollection(recordRow) {
        let record = {};
        record["GroupName"] = recordRow.CategoryName;
        record["GroupKey"] = recordRow.CategoryName;
        record["GroupPrice"] = recordRow.CategoryName;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Group");
    }

    async hOpenModal() {
        let lData = { message: "hello world" };
        let lModalPage = await this.aModalController.create({
            component: AdministratorAddGroupPage,
            componentProps: lData,
        });

        lModalPage.present();
    }
}
