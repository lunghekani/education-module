import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorGroupPage } from './administrator-group.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorGroupPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorGroupPageRoutingModule {}
