import { Component, OnInit } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { FirebaseService } from "src/services/firebase.service";
import { NewUserRegistrationPage } from "src/pages/new-user-registration/new-user-registration.page";

interface ContentData {
    Id: string;
    Username: string;
    Email: string;
    Administrator: boolean;
    Assessor: boolean;
    Instructor: boolean;
    Moderator: boolean;
    Learner: boolean;
}

@Component({
    selector: "app-administrator-user-table",
    templateUrl: "./administrator-user-table.page.html",
    styleUrls: ["./administrator-user-table.page.scss"],
})
export class AdministratorUserTablePage implements OnInit {
    hContents = [];
    ContentData: ContentData;

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService
    ) {
        this.ContentData = {} as ContentData;
    }

    ngOnInit() {
        this.aFirebaseService.readCollection("User").subscribe((data) => {
            this.hContents = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    Username: aEntryContent.payload.doc.data()["Username"],
                    Email: aEntryContent.payload.doc.data()["Email"],
                    Administrator: aEntryContent.payload.doc.data()[
                        "Administrator"
                    ],
                    Assessor: aEntryContent.payload.doc.data()["Assessor"],
                    Instructor: aEntryContent.payload.doc.data()["Instructor"],
                    Moderator: aEntryContent.payload.doc.data()["Moderator"],
                    Learner: aEntryContent.payload.doc.data()["Learner"],
                };
            });
            console.log(this.hContents);
        });
    }

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "User");
    }

    hUpdateCollection(recordRow) {
        let record = {};
        record["Username"] = recordRow.Username;
        record["Email"] = recordRow.Email;
        record["Administrator"] = recordRow.Administrator;
        record["Assessor"] = recordRow.Assessor;
        record["Instructor"] = recordRow.Instructor;
        record["Moderator"] = recordRow.Moderator;
        record["Learner"] = recordRow.Learner;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "User");
    }

    async hOpenModal() {
        let lData = { message: "hello world" };
        let lModalPage = await this.aModalController.create({
            component: NewUserRegistrationPage,
            componentProps: lData,
            cssClass: "new-user-registration"
		});
		
        lModalPage.present();
    }
}
