import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdministratorUserTablePageRoutingModule } from './administrator-user-table-routing.module';

import { AdministratorUserTablePage } from './administrator-user-table.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdministratorUserTablePageRoutingModule
  ],
  declarations: [AdministratorUserTablePage]
})
export class AdministratorUserTablePageModule {}
