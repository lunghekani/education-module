import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdministratorUserTablePage } from './administrator-user-table.page';

const routes: Routes = [
  {
    path: '',
    component: AdministratorUserTablePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministratorUserTablePageRoutingModule {}
