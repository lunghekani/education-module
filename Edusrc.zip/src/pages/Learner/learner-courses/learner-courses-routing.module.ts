import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { LearnerCoursesPage } from "./learner-courses.page";

const routes: Routes = [
    {
        path: "",
        component: LearnerCoursesPage,
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class LearnerCoursesPageRoutingModule {}
