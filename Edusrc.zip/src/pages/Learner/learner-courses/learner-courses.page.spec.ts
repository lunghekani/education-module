import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { LearnerCoursesPage } from './learner-courses.page';

describe('LearnerCoursesPage', () => {
  let component: LearnerCoursesPage;
  let fixture: ComponentFixture<LearnerCoursesPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LearnerCoursesPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(LearnerCoursesPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
