import { Component, OnInit } from '@angular/core';
import { FirebaseService } from 'src/services/firebase.service';
import { UserService } from 'src/services/user.local.service';

@Component({
  selector: 'app-learner-courses',
  templateUrl: './learner-courses.page.html',
  styleUrls: ['./learner-courses.page.scss'],
})
export class LearnerCoursesPage implements OnInit {
  hContents = [];
  hCategory = [{Name:"Accounting"},{Name:"Employee Training"}];
  hCourseLogo: string = "../././assets/img/CoursePlaceHolderImage.jpg";
  hLoggedInUser;

  constructor(
      private aFirebaseService: FirebaseService,
      private aUserService: UserService
  ) {}

  ngOnInit() {
      this.aFirebaseService.readCollection("Course").subscribe((data) => {
          this.hContents = data.map((aEntryContent) => {
              return {
                  Id: aEntryContent.payload.doc.id,
                  CourseName: aEntryContent.payload.doc.data()["CourseName"],
                  CourseCode: aEntryContent.payload.doc.data()["CourseCode"],
              };
          });
          console.log(this.hContents);
      });
  }

  ionViewDidEnter() {
    this.hLoggedInUser = this.aUserService.getUserName();
  }

}
