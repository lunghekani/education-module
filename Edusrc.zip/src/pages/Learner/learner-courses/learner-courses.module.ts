import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LearnerCoursesPageRoutingModule } from './learner-courses-routing.module';

import { LearnerCoursesPage } from './learner-courses.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LearnerCoursesPageRoutingModule
  ],
  declarations: [LearnerCoursesPage]
})
export class LearnerCoursesPageModule {}
