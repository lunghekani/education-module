import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learner-academic-information',
  templateUrl: './learner-academic-information.page.html',
  styleUrls: ['./learner-academic-information.page.scss'],
})
export class LearnerAcademicInformationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
