import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { LearnerAcademicInformationPage } from './learner-academic-information.page';

describe('LearnerAcademicInformationPage', () => {
  let component: LearnerAcademicInformationPage;
  let fixture: ComponentFixture<LearnerAcademicInformationPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LearnerAcademicInformationPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(LearnerAcademicInformationPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
