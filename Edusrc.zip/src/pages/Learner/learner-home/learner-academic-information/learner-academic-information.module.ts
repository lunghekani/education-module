import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LearnerAcademicInformationPageRoutingModule } from './learner-academic-information-routing.module';

import { LearnerAcademicInformationPage } from './learner-academic-information.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LearnerAcademicInformationPageRoutingModule
  ],
  declarations: [LearnerAcademicInformationPage]
})
export class LearnerAcademicInformationPageModule {}
