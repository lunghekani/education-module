import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/services/user.local.service';

@Component({
  selector: 'app-learner-discussion-comment',
  templateUrl: './learner-discussion-comment.page.html',
  styleUrls: ['./learner-discussion-comment.page.scss'],
})
export class LearnerDiscussionCommentPage implements OnInit {
  hLoggedInUser;
  UserDiscussion = {
    Message: "DiscussionMessage"
  }

  constructor(private aUserService: UserService) { }

  ngOnInit() {
  }

  ionViewDidEnter() {
    this.hLoggedInUser = this.aUserService.getUserName();
  }


  hDismissModal(){}

}
