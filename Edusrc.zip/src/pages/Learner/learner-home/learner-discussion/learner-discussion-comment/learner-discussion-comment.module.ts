import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LearnerDiscussionCommentPageRoutingModule } from './learner-discussion-comment-routing.module';

import { LearnerDiscussionCommentPage } from './learner-discussion-comment.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LearnerDiscussionCommentPageRoutingModule
  ],
  declarations: [LearnerDiscussionCommentPage]
})
export class LearnerDiscussionCommentPageModule {}
