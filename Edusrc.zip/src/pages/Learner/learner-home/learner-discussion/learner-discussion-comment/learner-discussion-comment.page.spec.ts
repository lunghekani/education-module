import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { LearnerDiscussionCommentPage } from './learner-discussion-comment.page';

describe('LearnerDiscussionCommentPage', () => {
  let component: LearnerDiscussionCommentPage;
  let fixture: ComponentFixture<LearnerDiscussionCommentPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LearnerDiscussionCommentPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(LearnerDiscussionCommentPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
