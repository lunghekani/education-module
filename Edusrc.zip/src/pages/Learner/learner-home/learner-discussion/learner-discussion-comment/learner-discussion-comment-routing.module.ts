import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LearnerDiscussionCommentPage } from './learner-discussion-comment.page';

const routes: Routes = [
  {
    path: '',
    component: LearnerDiscussionCommentPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LearnerDiscussionCommentPageRoutingModule {}
