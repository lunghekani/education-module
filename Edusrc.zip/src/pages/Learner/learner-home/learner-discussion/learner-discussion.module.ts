import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LearnerDiscussionPageRoutingModule } from './learner-discussion-routing.module';

import { LearnerDiscussionPage } from './learner-discussion.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LearnerDiscussionPageRoutingModule
  ],
  declarations: [LearnerDiscussionPage]
})
export class LearnerDiscussionPageModule {}
