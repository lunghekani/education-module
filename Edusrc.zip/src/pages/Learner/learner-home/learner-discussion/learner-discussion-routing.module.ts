import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { LearnerDiscussionPage } from "./learner-discussion.page";
import { LearnerDiscussionCommentPageModule } from "./learner-discussion-comment/learner-discussion-comment.module";

const routes: Routes = [
    {
        path: "",
        component: LearnerDiscussionPage,
        children: [
            {
                path: "learner-discussion-comment",
                loadChildren: () => LearnerDiscussionCommentPageModule,
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class LearnerDiscussionPageRoutingModule {}
