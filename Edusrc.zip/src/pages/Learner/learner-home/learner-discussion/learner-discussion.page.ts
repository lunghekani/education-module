import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { FirebaseService } from 'src/services/firebase.service';
import { LearnerDiscussionCommentPage } from './learner-discussion-comment/learner-discussion-comment.page';
import { InstructorAddDiscussionPage } from 'src/pages/Instructor/instructor-add-discussion/instructor-add-discussion.page';
import { UserService } from 'src/services/user.local.service';

@Component({
  selector: 'app-learner-discussion',
  templateUrl: './learner-discussion.page.html',
  styleUrls: ['./learner-discussion.page.scss'],
})
export class LearnerDiscussionPage implements OnInit {
  hUserDiscussions = [];
  hLoggedInUser;

  constructor(
      private aModalController: ModalController,
      private aFirebaseService: FirebaseService,
      private aUserService: UserService
  ) {}

  ngOnInit() {
      this.aFirebaseService.readCollection("Discussion").subscribe((data) => {
          this.hUserDiscussions = data.map((aEntryContent) => {
              return {
                  Id: aEntryContent.payload.doc.id,
                  Message: aEntryContent.payload.doc.data()["Message"],
              };
          });
          console.log(this.hUserDiscussions);
      });
  }

  ionViewDidEnter() {
    this.hLoggedInUser = this.aUserService.getUserName();
  }


  hRemoveCollection(rowID) {
      this.aFirebaseService.deleteCollection(rowID, "Discussion");
  }

  hUpdateCollection(recordRow) {
      let record = {};
      record["UnitName"] = recordRow.UnitName;
      record["CourseCode"] = recordRow.CourseCode;
      this.aFirebaseService.updateCollection(recordRow.Id, record, "Discussion");
  }

  async hOpenModal() {
      let lData = { message: "hello world" };
      let lModalPage = await this.aModalController.create({
          component: InstructorAddDiscussionPage,
          componentProps: lData,
      });
      lModalPage.present();
  }

  async hOpenDiscussion() {
    let lData = { message: "hello world" };
    let lModalPage = await this.aModalController.create({
        component: LearnerDiscussionCommentPage,
        componentProps: lData,
    });
    lModalPage.present();
  }
}
