import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { LearnerHomePage } from './learner-home.page';

describe('LearnerHomePage', () => {
  let component: LearnerHomePage;
  let fixture: ComponentFixture<LearnerHomePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LearnerHomePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(LearnerHomePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
