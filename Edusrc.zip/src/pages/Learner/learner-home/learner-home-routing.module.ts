import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { LearnerHomePage } from "./learner-home.page";
import { LearnerAcademicInformationPageModule } from "./learner-academic-information/learner-academic-information.module";
import { LearnerDiscussionPageModule } from "./learner-discussion/learner-discussion.module";

const routes: Routes = [
    {
        path: "",
        component: LearnerHomePage,
        children: [
            {
                path: "learner-academic-information",
                loadChildren: () => LearnerAcademicInformationPageModule,
            },
            {
                path: "learner-discussion",
                loadChildren: () => LearnerDiscussionPageModule,
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class LearnerHomePageRoutingModule {}
