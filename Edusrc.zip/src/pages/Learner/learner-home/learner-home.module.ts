import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LearnerHomePageRoutingModule } from './learner-home-routing.module';

import { LearnerHomePage } from './learner-home.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LearnerHomePageRoutingModule
  ],
  declarations: [LearnerHomePage]
})
export class LearnerHomePageModule {}
