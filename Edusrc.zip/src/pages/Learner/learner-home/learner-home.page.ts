import { Component, OnInit } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { FirebaseService } from "src/services/firebase.service";
import { LearnerAppealPage } from 'src/pages/appeal/learner-appeal.page';
import { UserService } from 'src/services/user.local.service';

@Component({
    selector: "app-learner-home",
    templateUrl: "./learner-home.page.html",
    styleUrls: ["./learner-home.page.scss"],
})
export class LearnerHomePage implements OnInit {
    hContents = [];
    hCategory = [{Name:"Accounting"},{Name:"Employee Training"}];
    hCourseLogo: string = "../././assets/img/CoursePlaceHolderImage.jpg";
    hLoggedInUser;
    hPageSegment = "list";
    hLearnerHome = "home";

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aUserService: UserService
    ) {}

    ngOnInit() {
        this.aFirebaseService.readCollection("Course").subscribe((data) => {
            this.hContents = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    CourseName: aEntryContent.payload.doc.data()["CourseName"],
                    CourseCode: aEntryContent.payload.doc.data()["CourseCode"],
                };
            });
            console.log(this.hContents);
        });
    }

    ionViewDidEnter() {
        this.hLoggedInUser = this.aUserService.getUserName();
      }
    

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Course");
    }

    hUpdateCollection(recordRow) {
        let record = {};
        record["UnitName"] = recordRow.UnitName;
        record["CourseCode"] = recordRow.CourseCode;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Course");
    }

    async hOpenModal(aEvent, type) {
        aEvent.stopPropagation();
        let lData = { message: "hello world" };
        let lModalPage;

        lModalPage = await this.aModalController.create({
            component: LearnerAppealPage,
            componentProps: lData,
        });
        lModalPage.present();
    }
}
