import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LearnerAppealListPage } from './learner-appeal-list.page';

const routes: Routes = [
  {
    path: '',
    component: LearnerAppealListPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LearnerAppealListPageRoutingModule {}
