import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LearnerAppealListPageRoutingModule } from './learner-appeal-list-routing.module';

import { LearnerAppealListPage } from './learner-appeal-list.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LearnerAppealListPageRoutingModule
  ],
  declarations: [LearnerAppealListPage]
})
export class LearnerAppealListPageModule {}
