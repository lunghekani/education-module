import { Component, OnInit } from "@angular/core";
import { ModalController } from "@ionic/angular";
import { FirebaseService } from "src/services/firebase.service";
import { UserService } from 'src/services/user.local.service';

@Component({
    selector: "app-learner-course",
    templateUrl: "./learner-course.page.html",
    styleUrls: ["./learner-course.page.scss"],
})
export class LearnerCoursePage implements OnInit {
    hCompletionRules = [];
    hContent;
    hAssessmentMethod = [];
    hDeliveryMethod = [];
    hCourse = {
		User: "User",
        CourseName: "CourseName",
        CourseCode: "CourseCode",
        Description: "CourseDescription",
	};
    hContents = [];
    hCategory = [{ Name: "Accounting" }, { Name: "Employee Training" }];
    hCourseLogo: string = "../././assets/img/CoursePlaceHolderImage.jpg";
    hLoggedInUser = "TestUser";
    hNextCourse = {
        User: "NextUser",
        CourseName: "NextCourseName",
        CourseCode: "NextCourseCode",
        Description: "NextCourseDescription",
    };

    constructor(
        private aModalController: ModalController,
        private aFirebaseService: FirebaseService,
        private aUserService: UserService
    ) {}

    ngOnInit() {
        this.aFirebaseService.readCollection("Course").subscribe((data) => {
            this.hContents = data.map((aEntryContent) => {
                return {
                    Id: aEntryContent.payload.doc.id,
                    CourseName: aEntryContent.payload.doc.data()["CourseName"],
                    User: aEntryContent.payload.doc.data()["User"],
                    CourseCode: aEntryContent.payload.doc.data()["CourseCode"],
                    Description: aEntryContent.payload.doc.data()[
                        "Description"
                    ],
                    NextCourse: aEntryContent.payload.doc.data()["NextCourse"],
                    CompletionRules: aEntryContent.payload.doc.data()[
                        "CompletionRules"
                    ],
                    AssessmentMethod: aEntryContent.payload.doc.data()[
                        "AssessmentMethod"
                    ],
                    DeliveryMethod: aEntryContent.payload.doc.data()[
                        "DeliveryMethod"
                    ],
                };
            });
            this.hCourse = this.hContents[0];
            console.log(this.hContents);
        });
    }

    ionViewDidEnter() {
        this.hLoggedInUser = this.aUserService.getUserName();
      }
    

    hRemoveCollection(rowID) {
        this.aFirebaseService.deleteCollection(rowID, "Course");
    }

    hUpdateCollection(recordRow) {
        let record = {};
        record["CourseName"] = recordRow.CourseName;
        record["User"] = recordRow.User;
        record["CourseCode"] = recordRow.CourseCode;
        record["Description"] = recordRow.Description;
        record["NextCourse"] = recordRow.NextCourse;
        record["CompletionRules"] = recordRow.CompletionRules;
        record["AssessmentMethod"] = recordRow.AssessmentMethod;
        record["DeliveryMethod"] = recordRow.DeliveryMethod;
        this.aFirebaseService.updateCollection(recordRow.Id, record, "Course");
    }

    async hOpenModal(aEvent, type) {
        aEvent.stopPropagation();
        let lData = { message: "hello world" };
        let lModalPage;

        // lModalPage = await this.aModalController.create({
        //     component: LearnerAppealPage,
        //     componentProps: lData,
        // });
        // lModalPage.present();
    }
}
