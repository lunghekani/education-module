import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { LearnerCoursePageRoutingModule } from './learner-course-routing.module';

import { LearnerCoursePage } from './learner-course.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    LearnerCoursePageRoutingModule
  ],
  declarations: [LearnerCoursePage]
})
export class LearnerCoursePageModule {}
