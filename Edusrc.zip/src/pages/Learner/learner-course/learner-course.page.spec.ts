import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { LearnerCoursePage } from './learner-course.page';

describe('LearnerCoursePage', () => {
  let component: LearnerCoursePage;
  let fixture: ComponentFixture<LearnerCoursePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LearnerCoursePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(LearnerCoursePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
