const firebaseConfig = {
    apiKey: "AIzaSyDILm1RCxKuHFHcBx07IEDP4su-E3WumWg",
    authDomain: "justinmindedu.firebaseapp.com",
    databaseURL: "https://justinmindedu.firebaseio.com",
    projectId: "justinmindedu",
    storageBucket: "justinmindedu.appspot.com",
    messagingSenderId: "448938213332",
    appId: "1:448938213332:web:4f6ba69a115310c1632041",
    measurementId: "G-NRH0RYLPQJ"
  };

  export default firebaseConfig;