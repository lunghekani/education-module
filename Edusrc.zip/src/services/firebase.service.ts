
import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {
  constructor(
    private firestore: AngularFirestore
  ) { }

  createCollection(aRecord, aCollectionName) {
    return this.firestore.collection(aCollectionName).add(aRecord);
  }

  readCollection(aCollectionName) {
    return this.firestore.collection(aCollectionName).snapshotChanges();
  }

  updateCollection(aRecordID, aRecord, aCollectionName) {
    this.firestore.doc(aCollectionName + '/' + aRecordID).update(aRecord);
  }

  deleteCollection(aRecordId, aCollectionName) {
    this.firestore.doc(aCollectionName + '/' + aRecordId).delete();
  }
}
