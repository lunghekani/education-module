import { Injectable } from "@angular/core";

@Injectable({
    providedIn: "root",
})
export class UserService {
    private UserName: string;
    private UserID: string;
    private AccountType: string;
    private UserLogoID: string;
    
    constructor() {}

    public getUserName(): string {
        return this.UserName;
    }

    public setUserName(aUserName: string) {
        this.UserName = aUserName;
    }
    
    public getUserID() : string {
        return this.UserID;
    }

    public setUserID(aUserID : string) {
        this.UserID = aUserID;
    }    

    public getAccountType() : string {
        return this.AccountType;
    }

    public setAccountType(aAccountType : string) {
        this.AccountType = aAccountType;
    }   

    public getUserLogoID() : string {
        return this.UserLogoID;
    }

    public setUserLogoID(aLogoID : string) {
        this.UserLogoID = aLogoID;
    }   
}
