import { NgModule } from "@angular/core";
import { MultiFileUploadComponent } from "./multi-file-upload.component";
import { CommonModule } from "@angular/common";
import { IonicModule } from "@ionic/angular";
import { FileUploadModule } from "ng2-file-upload";

@NgModule({
    imports: [CommonModule, IonicModule, FileUploadModule],
    declarations: [MultiFileUploadComponent],
    exports: [MultiFileUploadComponent],
})
export class MultiFileUploadComponentModule {}
