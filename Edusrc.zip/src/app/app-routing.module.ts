import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { LoginPageModule } from 'src/pages/login/login.module';
import { NewUserRegistrationPageModule } from 'src/pages/new-user-registration/new-user-registration.module';
import { OfficeSetupPageModule } from 'src/pages/office-setup/office-setup.module';
import { AdministratorDashboardPageModule } from 'src/pages/Administrator/administrator-dashboard/administrator-dashboard.module';
import { InstructorHomePageModule } from 'src/pages/Instructor/instructor-home/instructor-home.module';
import { AssessorHomePageModule } from 'src/pages/Assessor/assessor-home/assessor-home.module';
import { AssessorLearnerCoursesResultPageModule } from 'src/pages/Assessor/assessor-learner-courses-result/assessor-learner-courses-result.module';
import { ModeratorHomePageModule } from 'src/pages/Moderator/moderator-home/moderator-home.module';
import { ModeratorEvidenceRecordPageModule } from 'src/pages/Moderator/moderator-evidence-record/moderator-evidence-record.module';
import { ModeratorReportPageModule } from 'src/pages/Moderator/moderator-report/moderator-report.module';
import { InstructorAddConferencePageModule } from 'src/pages/Instructor/instructor-add-conference/instructor-add-conference.module';
import { InstructorConferencePageModule } from 'src/pages/Instructor/instructor-conference/instructor-conference.module';
import { InstructorAddDiscussionPageModule } from 'src/pages/Instructor/instructor-add-discussion/instructor-add-discussion.module';
import { InstructorDiscussionPageModule } from 'src/pages/Instructor/instructor-discussion/instructor-discussion.module';
import { LearnerHomePageModule } from 'src/pages/Learner/learner-home/learner-home.module';
import { AdministratorUserTablePageModule } from 'src/pages/Administrator/administrator-user-table/administrator-user-table.module';
import { AdministratorAddCoursePageModule } from 'src/pages/Administrator/administrator-add-course/administrator-add-course.module';
import { AdministratorAddCategoryPageModule } from 'src/pages/Administrator/administrator-add-category/administrator-add-category.module';
import { AdministratorCategoryPageModule } from 'src/pages/Administrator/administrator-category/administrator-category.module';
import { AdministratorCoursePageModule } from 'src/pages/Administrator/administrator-course/administrator-course.module';
import { AdministratorCourseTypePageModule } from 'src/pages/Administrator/administrator-course-type/administrator-course-type.module';
import { AdministratorUserAccountPageModule } from 'src/pages/Administrator/administrator-user-account/administrator-user-account.module';
import { AdministratorAddAssignmentPageModule } from 'src/pages/Administrator/administrator-add-assignment/administrator-add-assignment.module';
import { AdministratorAddInstructorTrainingPageModule } from 'src/pages/Administrator/administrator-add-instructor-training/administrator-add-instructor-training.module';
import { AdministratorAddInstructorTrainingSessionPageModule } from 'src/pages/Administrator/administrator-add-instructor-training-session/administrator-add-instructor-training-session.module';
import { AdministratorContentCreatorPageModule } from 'src/pages/Administrator/administrator-content-creator/administrator-content-creator.module';
import { UserCalendarPageModule } from 'src/pages/user-calendar/user-calendar.module';
import { AssessorEnrollUsersPageModule } from 'src/pages/Assessor/assessor-home/assessor-enroll-users/assessor-enroll-users.module';
import { AssessorCourseReportPageModule } from 'src/pages/Assessor/assessor-home/assessor-course-report/assessor-course-report.module';
import { ModeratorEnrolledLearnersPageModule } from 'src/pages/Moderator/moderator-home/moderator-enrolled-learners/moderator-enrolled-learners.module';
import { ModeratorAssessorResultsPageModule } from 'src/pages/Moderator/moderator-home/moderator-assessor-results/moderator-assessor-results.module';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => LoginPageModule
  },
  {
    path: 'new-user-registration',
    loadChildren: () => NewUserRegistrationPageModule
  },            {
    path: "user-calendar",
    loadChildren: () => UserCalendarPageModule,
},
  {
    path: 'office-setup',
    loadChildren: () => OfficeSetupPageModule
  },
  {
    path: 'administrator-dashboard',
    loadChildren: () => AdministratorDashboardPageModule
  },
  {
    path: 'instructor-home',
    loadChildren: () => InstructorHomePageModule
  },
  {
    path: 'assessor-home',
    loadChildren: () => AssessorHomePageModule
  },
  {
    path: 'assessor-learner-courses-result',
    loadChildren: () => AssessorLearnerCoursesResultPageModule
  },
  {
    path: 'moderator-home',
    loadChildren: () => ModeratorHomePageModule
  },
  {
    path: 'moderator-evidence-record',
    loadChildren: () => ModeratorEvidenceRecordPageModule
  },
  {
    path: 'moderator-report',
    loadChildren: () =>  ModeratorReportPageModule
  },
  {
    path: 'instructor-add-conference',
    loadChildren: () =>  InstructorAddConferencePageModule
  },
  {
    path: 'instructor-conference',
    loadChildren: () => InstructorConferencePageModule
  },
  {
    path: 'instructor-add-discussion',
    loadChildren: () => InstructorAddDiscussionPageModule
  },
  {
    path: 'instructor-discussion',
    loadChildren: () => InstructorDiscussionPageModule
  },
  {
    path: 'learner-home',
    loadChildren: () =>LearnerHomePageModule
  },
  {
    path: 'administrator-user-table',
    loadChildren: () => AdministratorUserTablePageModule
  },
  {
    path: 'administrator-add-course',
    loadChildren: () => AdministratorAddCoursePageModule
  },
  {
    path: 'administrator-add-category',
    loadChildren: () => AdministratorAddCategoryPageModule
  },
  {
    path: 'administrator-category',
    loadChildren: () => AdministratorCategoryPageModule
  },
  {
    path: 'administrator-course',
    loadChildren: () => AdministratorCoursePageModule
  },
  {
    path: 'administrator-course-type',
    loadChildren: () => AdministratorCourseTypePageModule
  },  
  {
    path: 'administrator-user-account',
    loadChildren: () => AdministratorUserAccountPageModule
  },
  {
    path: 'administrator-add-assignment',
    loadChildren: () => AdministratorAddAssignmentPageModule
  },
  {
    path: 'administrator-add-instructor-training',
    loadChildren: () => AdministratorAddInstructorTrainingPageModule
  },
  {
    path: 'administrator-add-instructor-training-session',
    loadChildren: () => AdministratorAddInstructorTrainingSessionPageModule
  },
  {
    path: 'administrator-content-creator',
    loadChildren: () => AdministratorContentCreatorPageModule
  },
  {
    path: 'administrator-add-content-web',
    loadChildren: () => import('../pages/Administrator/administrator-content-creator/administrator-add-content-web/administrator-add-content-web.module').then( m => m.AdministratorAddContentWebPageModule)
  },
  {
    path: 'administrator-add-content-test-randomized',
    loadChildren: () => import('../pages/Administrator/administrator-content-creator/administrator-add-content-test-randomized/administrator-add-content-test-randomized.module').then( m => m.AdministratorAddContentTestRandomizedPageModule)
  },
  {
    path: 'new-learner-registration',
    loadChildren: () => import('../pages/new-learner-registration/new-learner-registration.module').then( m => m.NewLearnerRegistrationPageModule)
  },
  {
    path: 'administrator-add-group',
    loadChildren: () => import('../pages/Administrator/administrator-add-group/administrator-add-group.module').then( m => m.AdministratorAddGroupPageModule)
  },
  {
    path: 'administrator-group',
    loadChildren: () => import('../pages/Administrator/administrator-group/administrator-group.module').then( m => m.AdministratorGroupPageModule)
  },
  {
    path: 'learner-appeal',
    loadChildren: () => import('../pages/appeal/learner-appeal.module').then( m => m.LearnerAppealPageModule)
  },
  {
    path: 'learner-appeal-list',
    loadChildren: () => import('../pages/learner/learner-appeal-list/learner-appeal-list.module').then( m => m.LearnerAppealListPageModule)
  },
  {
    path: 'assessor-learner-appeal-list',
    loadChildren: () => import('../pages/assessor/assessor-learner-appeal-list/assessor-learner-appeal-list.module').then( m => m.AssessorLearnerAppealListPageModule)
  },
  {
    path: 'moderator-learner-appeal-list',
    loadChildren: () => import('../pages/moderator/moderator-learner-appeal-list/moderator-learner-appeal-list.module').then( m => m.ModeratorLearnerAppealListPageModule)
  },
  {
    path: 'learner-course',
    loadChildren: () => import('../pages/Learner/learner-course/learner-course.module').then( m => m.LearnerCoursePageModule)
  },
  {
    path: "learner-courses",
    loadChildren: () => import('../pages/Learner/learner-courses/learner-courses.module').then( m => m.LearnerCoursesPageModule),
},
  {
    path: 'administrator-add-qctopractical-component',
    loadChildren: () => import('../pages/Administrator/administrator-add-qctopractical-component/administrator-add-qctopractical-component.module').then( m => m.AdministratorAddQCTOPracticalComponentPageModule)
  },
  {
    path: 'administrator-assessment-qctopractical-component',
    loadChildren: () => import('../pages/Administrator/administrator-assessment-qctopractical-component/administrator-assessment-qctopractical-component.module').then( m => m.AdministratorAssessmentQCTOPracticalComponentPageModule)
  },
  {
    path: "assessor-enroll-users",
    loadChildren: () => AssessorEnrollUsersPageModule,
},
{
    path: "assessor-course-report",
    loadChildren: () => AssessorCourseReportPageModule,
},
{
  path: "moderator-enrolled-learners",
  loadChildren: () => ModeratorEnrolledLearnersPageModule,
},
{
  path: "moderator-assessor-results",
  loadChildren: () => ModeratorAssessorResultsPageModule,
},
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
